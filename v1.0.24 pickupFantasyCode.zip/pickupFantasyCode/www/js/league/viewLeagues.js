var test = [
				{"id":2,"leagueID":0,"name":"newl","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"newll","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"Wild","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"new","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"Test","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"},
				{"id":2,"leagueID":0,"name":"league-a","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"league-b","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"league-c","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"league-d","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"league-e","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"},
				{"id":2,"leagueID":0,"name":"league-f","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"league-g","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"league-h","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"league-i","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"league-j","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"},
				{"id":2,"leagueID":0,"name":"league-k","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"league-l","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"league-m","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"league-n","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"league-o","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"},
				{"id":2,"leagueID":0,"name":"league-p","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"league-q","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"league-r","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"league-s","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"league-t","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"},
				{"id":2,"leagueID":0,"name":"league-u","password":"","numPlayers":2,"member1":"joe","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11110","url":"http://cryptic-waters-6734.herokuapp.com/leagues/2.json"},
				{"id":3,"leagueID":0,"name":"league-v","password":"","numPlayers":6,"member1":"newbie","member2":"joe","member3":"joe","member4":"modano","member5":"ankil","member6":"yoyo","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/3.json"},
				{"id":6,"leagueID":0,"name":"league-w","password":"","numPlayers":4,"member1":"wild","member2":"","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"10000","url":"http://cryptic-waters-6734.herokuapp.com/leagues/6.json"},
				{"id":4,"leagueID":0,"name":"league-x","password":"pass","numPlayers":6,"member1":"joe","member2":"heya","member3":"ankil2","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/4.json"},
				{"id":7,"leagueID":0,"name":"league-y","password":"","numPlayers":5,"member1":"joe","member2":"blah","member3":"","member4":"","member5":"","member6":"","gamesOfWeekIdentifier":"11111","url":"http://cryptic-waters-6734.herokuapp.com/leagues/7.json"}
			];

var userInfo = localStorage["loggedIn"].split(",");
var body = document.getElementById("contentWrapper");
body.style.paddingTop = "45%";

// create header of the page
var header = document.createElement("h2");
header.innerHTML = "Open Leagues";
header.style.paddingLeft="30%";

// create wrapper div for table
var tableWrapper = document.createElement("div");
tableWrapper.id = "tableWrapper";
tableWrapper.style.overflowY = "auto";
tableWrapper.className = "swiper-container";
tableWrapper.style.width = "97%";
tableWrapper.style.height = $(window).height()*.59 + "px";
tableWrapper.style.border = "4px solid white";
tableWrapper.style.borderRadius = "15px";
tableWrapper.style.background = "gray";

var table = document.createElement("table");
table.className = "draftProspectTable";
table.style.width = "100%";
table.style.borderRadius = "15px";

var tblBody = document.createElement("tbody");
tblBody.style.borderRadius = "15px";

// table header row
var tblHeader = document.createElement("tr");
tblHeader.style.backgroundColor = "black";
tblHeader.setAttribute("id", "draftedTableRowHeader");
tblHeader.style.borderRadius = "15px";


// header data
var header1 = document.createElement("td");
var header2 = document.createElement("td");
var header3 = document.createElement("td");
var header4 = document.createElement("td");

header1.innerHTML = "League Name";
header2.innerHTML = "Max Spots";
header3.innerHTML = "Teams";
header4.innerHTML = "";

header1.style.width = "25%";
header2.style.width = "25%";
header3.style.width = "25%";
header4.style.width = "25%";

header1.style.backgroundColor = "black";
header4.style.backgroundColor = "black";

header1.style.borderTopLeftRadius = "14px";
header4.style.borderTopRightRadius = "14px";

tblHeader.appendChild(header1);
tblHeader.appendChild(header2);
tblHeader.appendChild(header3);
tblHeader.appendChild(header4);

tblBody.appendChild(tblHeader);

var leagues = getLeagues();
for(var i = 0; i < leagues.length; i++) {
	var key = leagues[i];
	numPlayers = findNumPlayers(key);

	tblTR = document.createElement("tr");
	tblTR.style.border = "1px solid black";

	var tblTD1 = document.createElement("td");
	var tblTD2 = document.createElement("td");
	var tblTD3 = document.createElement("td");
	var tblTD4 = document.createElement("td");

	tblTD1.style.border = "1px solid black";
	tblTD2.style.border = "1px solid black";
	tblTD3.style.border = "1px solid black";

	tblTD1.style.textAlign = "center";
	tblTD2.style.textAlign = "center";
	tblTD3.style.textAlign = "center";
	tblTD4.style.textAlign = "center";

	if(key.password != "") {
		continue;
	}
	else if(key.numPlayers <= numPlayers) {
		continue;
	}

	tblTD1.innerHTML = key.name;
	tblTD2.innerHTML = key.numPlayers;
	tblTD3.innerHTML = numPlayers;


	tblTD4.className = "draftButtonColumn";
		var joinBtn = document.createElement("a");
		joinBtn.className = "draftProspectButton";
		joinBtn.style.cssFloat = "none";
		joinBtn.innerHTML = "Join";
		joinBtn.setAttribute("href", "javascript:joinLeague("+JSON.stringify(key.name)+")");
		tblTD4.appendChild(joinBtn)

	tblTR.appendChild(tblTD1);
	tblTR.appendChild(tblTD2);
	tblTR.appendChild(tblTD3);
	tblTR.appendChild(tblTD4);
	tblBody.appendChild(tblTR);
}


table.appendChild(tblBody);
tableWrapper.appendChild(table);

body.appendChild(header);
body.appendChild(tableWrapper);

function getLeagues() {
	var URL = "http://cryptic-waters-6734.herokuapp.com/leagues.json";
	var json = getRequest(URL);
	return json;
	//return test;
}
function findNumPlayers(league) {
	if(league.member2 == "") {
		return 1;
	}
	else if(league.member3 == "") {
		return 2;
	}
	else if(league.member4 == "") {
		return 3;
	}
	else if(league.member5 == "") {
		return 4;
	}
	else if(league.member6 == "") {
		return 5;
	}
	else {
		return 6;
	}
}

function joinLeague(leagueName) {
	var confirmation = confirm("Are you sure you want to join the league: \""+leagueName+"\"?");
	setTimeout(loading,1);
	if(confirmation) {
		sendRequests(leagueName);
	}
	setTimeout(notLoading,1000);
}

function sendRequests(leagueName) {
	// URL's for requests
	var userURL = 'http://cryptic-waters-6734.herokuapp.com/users/'+userInfo[1]+'.json';
	leagueURL = 'http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueName+'.json';

	// GET request to get league id
	leagueJson = getRequest(leagueURL);
	if(leagueJson == 0) {
		alert("Could not find league. Please try again.");
		setTimeout(notLoading,1000);
		return;
	}
	if( (leagueJson[0].password != "" ) && (leagueJson[0].password != password.value)  ) {
		alert("Incorrect Password");
		setTimeout(notLoading,1000);
		return;
	}

	// check to see what spot to put the user
	var memNum = 0;
	if(leagueJson[0].member1 == "") {
		memNum = 0;
		var leagueData = {
			league : {
				member1 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member2 == "") {
		memNum = 1;
		var leagueData = {
			league : {
				member2 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member3 == "") {
		memNum = 2;
		var leagueData = {
			league : {
				member3 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member4 == "") {
		memNum = 3;
		var leagueData = {
			league : {
				member4 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member5 == "") {
		memNum = 4;
		var leagueData = {
			league : {
				member5 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member6 == "") {
		memNum = 5;
		var leagueData = {
			league : {
				member6 : userInfo[0]
			}
		}
	}
	else {
		alert("There is no more room in this league.");
		setTimeout(notLoading,1000);
		return;
	}

	// check to see if there is room in the league for the user
	if(memNum >= leagueJson[0].numPlayers) {
		alert("There is no more room in this league.");
		setTimeout(notLoading,1000);
		return;	
	}

	// PUT request to update the user table to add the new league id
	var userData = {
		user : {
			leagueName : leagueJson[0].name,
			rosterID : "0"
		}
	}
	var userJson = putRequest(userURL, userData);
	if(userJson == 0) {
		alert("Failed to update user info; please try again");
		setTimeout(notLoading,1000);
		return;
	}

	// PUT request to update the league table to add the username
	leagueURL = 'http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueJson[0].id+'.json';
	var leagueJson = putRequest(leagueURL, leagueData);
	if (leagueJson == 0) {
		alert("Failed to add user to league; please try again");
		setTimeout(notLoading,1000);
		return;
	}
	else {
		alert("Successfully joined League");
		location.reload();
		return;
	}
}

// allow scrolling for ankil's phone
function isTouchDevice() {
	try {
		document.createEvent("TouchEvent");
		return true;
	} catch (e) {
		return false;
	}
}
function touchScroll(id) {
	if(isTouchDevice()) { //if touch events exist...
		var el=document.getElementById(id);
		var scrollStartPos=0;

		document.getElementById(id).addEventListener("touchstart", function(event) {
			scrollStartPos=this.scrollTop+event.touches[0].pageY;
		},false);

		document.getElementById(id).addEventListener("touchmove", function(event) {
			this.scrollTop=scrollStartPos-event.touches[0].pageY;
		},false);
	}
}
touchScroll('tableWrapper');