var body = document.getElementById("contentWrapper");

// create elements
var loginHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var username = document.createElement("input");
var password = document.createElement("input");

var login = document.createElement("button");

loginHeader.innerHTML = "Login";
loginHeader.className = "underline";

userHeader.innerHTML = "Username:";
passHeader.innerHTML = "Password:";

username.type = "text";
username.id = "username";

password.type = "password";
password.id = "password";

login.innerHTML = "Log in";
login.className = "myButton";
login.onclick = function() {
    if(username.value == "" || password.value == "") {
        alert("Username or password is empty");
    }
    else {
        loading();
        var url = 'http://cryptic-waters-6734.herokuapp.com/users/'+username.value+'.json';
        var json = getRequest(url);
        if(json != 0) {
            if( (json[0].username == username.value) && (json[0].phoneCred == password.value) ){
                fillButton("login", document.getElementById("logout"));
                localStorage["loggedIn"] = username.value + "," + json[0].id;
                location.reload();
            }
            else {
                alert("Invalid password");
                notLoading();
            }
        }
        else {
            alert("Invalid username");  
            notLoading();
        }
    }
};

body.appendChild(loginHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(passHeader); 
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(login);                

