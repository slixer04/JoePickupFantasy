var body = document.getElementById("contentWrapper");
var userInfo = localStorage["loggedIn"].split(",");

// create all the html variables
var createHeader = document.createElement("h2");
var leagueHeader = document.createElement("h2");
var numHeader = document.createElement("h2");
var slotsHeader = document.createElement("h2");
var startHeader = document.createElement("label");
var endHeader = document.createElement("label");
var passHeader = document.createElement("h2");

var leagueName = document.createElement("input");
var teamNum = document.createElement("select");
var startTime = document.createElement("select");
var endTime = document.createElement("select");
var pass = document.createElement("input");

var createBtn = document.createElement("button");

// set all the attributes of the html variables
createHeader.innerHTML = "Create League";
createHeader.className = "underline";

leagueHeader.innerHTML = "League Name:";
numHeader.innerHTML = "Number of Teams:";
slotsHeader.innerHTML = "Game Times Slot(s):";
startHeader.innerHTML = "Start Time:";
endHeader.innerHTML = "End Time:  ";
passHeader.innerHTML = "(Optional) Private password";

leagueName.id = "leagueName";
leagueName.type = "text";

teamNum.id = "teamNum";       
teamNum.options[teamNum.options.length] = new Option("2","2");  
teamNum.options[teamNum.options.length] = new Option("3","3");  
teamNum.options[teamNum.options.length] = new Option("4","4");  
teamNum.options[teamNum.options.length] = new Option("5","5");
teamNum.options[teamNum.options.length] = new Option("6","6");

startTime.id = "startTime";
startTime.options[startTime.options.length] = new Option("Thursday - Night","1");
startTime.options[startTime.options.length] = new Option("Sunday - Noon","2");
startTime.options[startTime.options.length] = new Option("Sunday - Evening","3");
startTime.options[startTime.options.length] = new Option("Sunday - Night","4"); 
startTime.options[startTime.options.length] = new Option("Monday - Night","5"); 

endTime.id = "endTime";
endTime.options[endTime.options.length] = new Option("Thursday - Night","1");
endTime.options[endTime.options.length] = new Option("Sunday - Evening","2");
endTime.options[endTime.options.length] = new Option("Sunday - Evening","3");
endTime.options[endTime.options.length] = new Option("Sunday - Night","4"); 
endTime.options[endTime.options.length] = new Option("Monday - Night","5"); 

pass.id = "pass";
pass.type = "text";

createBtn.innerHTML = "Create";
createBtn.className = "myButton";
createBtn.onclick = function () {
	loading();

	if(startTime.value > endTime.value) {
		alert("The start time is after the end time");
		notLoading();
		return;
	}
	if(leagueName.value == "") {
		alert("Enter a team name");
		notLoading();
		return;
	}
	
	sendRequests();  
}

body.appendChild(createHeader);
body.appendChild(leagueHeader);
body.appendChild(leagueName);
body.appendChild(document.createElement("br"));
body.appendChild(numHeader);
numHeader.appendChild(teamNum);
body.appendChild(slotsHeader);
body.appendChild(startHeader);
body.appendChild(startTime);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(endHeader);
body.appendChild(endTime);
body.appendChild(document.createElement("br"));
body.appendChild(passHeader);
body.appendChild(pass);
body.appendChild(document.createElement("br"));
body.appendChild(createBtn);


function findCode() {
	var firstBit = startTime.value;
	var lastBit = endTime.value;
	range = firstBit - lastBit;
	var code = ""
	for(i=1;i<6;i++) {
		if(i >= firstBit && i <= lastBit)
			code += "1";
		else
			code += "0";
	}
	return code;
}
function sendRequests() {
	var gameCode = findCode();

	// URL's for requests
	var checkURL = 'http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueName.value+'.json';
	var leagueURL = 'http://cryptic-waters-6734.herokuapp.com/leagues.json';
	var userURL = 'http://cryptic-waters-6734.herokuapp.com/users/'+userInfo[1]+'.json';

	
	// GET request to see if league name is already taken
	var checkJson = getRequest(checkURL);
	if(checkJson != 0) {
		alert("League name is already taken");
		notLoading();
		return;
	}
	else {

		// POST request to add the league to the server
		var leagueData = {
				league : {
					leagueID : "0",
					name : leagueName.value,
					password : pass.value,
					numPlayers : teamNum.value,
					member1 : userInfo[0],
					member2 : "",
					member3 : "",
					member4 : "",
					member5 : "",
					member6 : "",
					gamesOfWeekIdentifier : gameCode
				}
		}
		var leagueJson = postRequest(leagueURL,leagueData);
		if(leagueJson == 0) {
			alert("Failed to create league; please try again");
			location.reload();
		}
		else {
			var userData = {
				user: {
					leagueID : leagueJson.id,
					rosterID : "0"
				}
			}
			// PUT request to update the user table to add the new league id
			var userJson = putRequest(userURL, userData);
			if(userJson == 0) {
				alert("Failed to update user info; please try again");W
				var deleteJson = deleteRequest('http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueJson.id+'.json');
				location.reload();
			}
			else {
				alert("Successfully created League");
				notLoading();
				hideHome();
				localStorage["leagueInfo"] = leagueJson.id + "," + leagueName.value;
				loadScript("js/league/draftTeam.js");
				return;
			}
		}
	}
}

