var body = document.getElementById("contentWrapper");

// create elements
var loginHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var username = document.createElement("input");
var password = document.createElement("input");

var login = document.createElement("button");

loginHeader.innerHTML = "Login";
loginHeader.className = "underline";

userHeader.innerHTML = "Username:";
passHeader.innerHTML = "Password:";

username.type = "text";
username.id = "username";

password.type = "password";
password.id = "password";

login.innerHTML = "Log in";
login.className = "myButton";
login.addEventListener('touchstart',function() {
    if(username.value == "" || password.value == "") {
        alert("Username or password is empty");
    }
    else {
        setTimeout(loading,1);
        sendRequests();
    }
});

body.appendChild(loginHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(passHeader); 
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(login);

function sendRequests() {
    var url = 'http://cryptic-waters-6734.herokuapp.com/users/'+username.value.trim()+'.json';
    var json = getRequest(url);
    if(json == -1) {
        alert("Connection failure; Please try again");
        location.reload();
    }
    else if(json != 0) {
        if( (json[0].username == username.value.trim()) && (json[0].phoneCred == password.value.trim()) ){
            fillButton("login", document.getElementById("logout"));
            localStorage["loggedIn"] = username.value.trim() + "," + json[0].id;
            location.reload();
        }
        else {
            alert("Invalid password");
            setTimeout(notLoading,1000);
            return;
        }
    }
    else {
        alert("Invalid username");  
        setTimeout(notLoading,1000);
        return;
    }
}                

