var body = document.getElementById("contentWrapper");
var userInfo = localStorage["loggedIn"].split(",");

// create elements
var joinHeader = document.createElement("h2");
var nameHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var leagueName = document.createElement("input");
var password = document.createElement("input");

var btn = document.createElement("button");
var viewBtn = document.createElement("button");

// set elements attributes
joinHeader.innerHTML = "Join League";
joinHeader.className = "underline";

nameHeader.innerHTML = "League Name:";
passHeader.innerHTML = "Password:";

leagueName.id = "leagueName";
leagueName.type="text";

password.id="password";
password.type="text";

btn.innerHTML = "Join";
btn.className = "myButton";
btn.addEventListener('touchstart',function() {
	
	if(leagueName.value == "") {
		alert("Requires a league name.");
		return;
	}

	setTimeout(loading,1);
	sendRequests();
});

viewBtn.innerHTML = "View Open Leagues";
viewBtn.className = "myButton";
viewBtn.addEventListener('touchstart',function() {
	loadScript("js/league/viewLeagues.js");
});

// add to document
body.appendChild(joinHeader);
body.appendChild(nameHeader);
body.appendChild(leagueName);
body.appendChild(passHeader);
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(btn);
body.appendChild(viewBtn);


function sendRequests() {
	// URL's for requests
	var userURL = 'http://cryptic-waters-6734.herokuapp.com/users/'+userInfo[1]+'.json';
	leagueURL = 'http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueName.value.trim()+'.json';

	// GET request to get league id
	leagueJson = getRequest(leagueURL);
	if(leagueJson == 0) {
		alert("Could not find league. Please try again.");
		setTimeout(notLoading,1000);
		return;
	}
	if( (leagueJson[0].password != "" ) && (leagueJson[0].password != password.value.trim())  ) {
		alert("Incorrect Password");
		setTimeout(notLoading,1000);
		return;
	}

	// check to see what spot to put the user
	var memNum = 0;
	if(leagueJson[0].member1 == "") {
		memNum = 0;
		var leagueData = {
			league : {
				member1 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member2 == "") {
		memNum = 1;
		var leagueData = {
			league : {
				member2 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member3 == "") {
		memNum = 2;
		var leagueData = {
			league : {
				member3 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member4 == "") {
		memNum = 3;
		var leagueData = {
			league : {
				member4 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member5 == "") {
		memNum = 4;
		var leagueData = {
			league : {
				member5 : userInfo[0]
			}
		}
	}
	else if(leagueJson[0].member6 == "") {
		memNum = 5;
		var leagueData = {
			league : {
				member6 : userInfo[0]
			}
		}
	}
	else {
		alert("There is no more room in this league.");
		setTimeout(notLoading,1000);
		return;
	}

	// check to see if there is room in the league for the user
	if(memNum >= leagueJson[0].numPlayers) {
		alert("There is no more room in this league.");
		setTimeout(notLoading,1000);
		return;	
	}

	// PUT request to update the user table to add the new league id
	var userData = {
		user : {
			leagueName : leagueJson[0].name,
			rosterID : "0"
		}
	}
	var userJson = putRequest(userURL, userData);
	if(userJson == 0) {
		alert("Failed to update user info; please try again");
		setTimeout(notLoading,1000);
		return;
	}

	// PUT request to update the league table to add the username
	leagueURL = 'http://cryptic-waters-6734.herokuapp.com/leagues/'+leagueJson[0].id+'.json';
	var leagueJson = putRequest(leagueURL, leagueData);
	if (leagueJson == 0) {
		alert("Failed to add user to league; please try again");
		setTimeout(notLoading,1000);
		return;
	}
	else {
		alert("Successfully joined League");
		location.reload();
		return;
	}
}