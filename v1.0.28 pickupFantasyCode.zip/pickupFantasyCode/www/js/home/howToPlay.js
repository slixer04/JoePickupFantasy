//Called to create the how to play page
createHowToPlayPage();

function createHowToPlayPage() {
	var body = document.getElementById("contentWrapper");
	body.style.paddingTop = "45%";

	// Add header
	var header = document.createElement("h2");
	header.innerHTML = "How To Play";
	header.style.textAlign = "center";
	header.style.marginBottom = "3%";
	body.appendChild(header);

	// Make the tabs outline
	var tabContainer = document.createElement("div");
	tabContainer.className = "fullSize";
	tabContainer.className = "swiper-container";
	tabContainer.style.width = "97%";
	//tabContainer.style.height = (window.screen.height - (window.screen.height * .74)) + "px";
	tabContainer.style.height = $(window).height() * .59 + "px";
	tabContainer.style.border = "4px solid white";
	tabContainer.style.borderRadius = "15px";

	//Create Wrapper for tabs
	var tabWrapper = document.createElement("div");
	tabWrapper.className = "fullSize";
	tabWrapper.className = "swiper-wrapper";
	//tabWrapper.style.marginTop = "3%";

	var tabs1 = document.createElement("div");
	tabs1.className = "fullSize";
	tabs1.className = "swiper-container";
	//tabs1.style.height = "90%";
	//tabs1.style.width = "97%";
	//tabs1.style.height = (window.screen.height - (window.screen.height * .74)) + "px";
	tabs1.style.height = $(window).height() * .61 + "px";
	tabs1.style.borderRadius = "10px";
	tabs1.style.background = "Gray";
	tabs1.appendChild(createTabs());

	tabWrapper.appendChild(tabs1);
	tabContainer.appendChild(tabWrapper);
	
	body.appendChild(tabContainer);
}

//Draw and create the tabs
function createTabs()
{
	//Create div to hold tabs
	var tabs = document.createElement("div");
	tabs.setAttribute("id", "tabs-howToPlay");
	tabs.className = "tabsStyle";				
	
		//Create tabs
		var ul = document.createElement("ul");	
			var scoring_li = document.createElement("li");
				var a1 = document.createElement("a");
					a1.setAttribute("href", "#tabs-scoring");
					a1.innerHTML = "Scoring";
				scoring_li.appendChild(a1);
			ul.appendChild(scoring_li);
			
			var create_li = document.createElement("li");
				var a2 = document.createElement("a");
					a2.setAttribute("href", "#tabs-create");
					a2.innerHTML = "Create League";
				create_li.appendChild(a2);
			ul.appendChild(create_li);
			
			var join_draft_li = document.createElement("li");
				var a3 = document.createElement("a");
					a3.setAttribute("href", "#tabs-join");
					a3.innerHTML = "Join/Draft";
				join_draft_li.appendChild(a3);
			ul.appendChild(join_draft_li);
			
		tabs.appendChild(ul);
		
		/*//Fetch draftable players
		loading();
		fetchPlayers(getLeagueTimeSlot());
		notLoading();*/

		
		//Tab1
		var score_tab = document.createElement("div");
		score_tab.className = "tabs";
		score_tab.setAttribute("id", "tabs-scoring");
		score_tab.innerHTML = "<b>Quarterback:</b><br /><b>+1:</b> Every 25 yrds of pass completions.<br /><b>+2:</b> Successful 2 point conversion.<br /><b>+4:</b> Touchdown!!!<br /><br /><b>Running Back:</b><br /><b>+1:</b> Every 10 rushing yrds.<br /><b>+6:</b> Touchdown Rush!!!<br /><b>+2:</b> Successful 2 point conversion rush.<br /><br /><b>Receiver/Tight End:</b><br /><b>+1:</b> Every 10 receiving yrds.<br /><b>+6:</b> Touchdown Reception!!!<br /><b>+2:</b> Successful 2 point conversion reception.<br /><br /><b>Kicker:</b><br /><b>+1:</b> Successful extra point kick.<br /><b>+3:</b> Field goal from < 39 yrds.<br /><b>+4:</b> Field goal from between 40 and 49 yrds.<br /><b>+5:</b> Field goal from >= 50 yrds.<br /><b>-1 :</b> Unsuccessful field goal attempt.";
		tabs.appendChild(score_tab);
		
		//Tab2
		var create_tab = document.createElement("div");
		create_tab.className = "tabs";
		create_tab.setAttribute("id", "tabs-create");
		create_tab.innerHTML = "<b>1. League Name:</b> It is the name of your League. Other team owners will need this name to join your League. <br /><br /> <b>2. Num of Teams:</b> It is to limit the number of teams to your League. Maximum number of teams can be allowed per league is 6. <br /><br /> <b>3. Game Slots:</b> Pick the slots you want to play. Keep in mind that you can only choose the slots in sequence. i.e. Thursday - Night to Sunday - Evening, but can't do Thursday - Night to Sunday - Evening then Monday - Night. <br /><br /> <b>4. Password:</b> Only provide password if you want to make your League private. If you create password, you'll have to give it to other team owners who wish to join your League.";
		tabs.appendChild(create_tab);
		
		//Tab3
		var join_tab = document.createElement("div");
		join_tab.className = "tabs";
		join_tab.setAttribute("id", "tabs-join");
		join_tab.innerHTML = "<b>Join</b> <br /><br /> <b>1. League Name:</b> Enter the name obtained from the League owner. <br /><br /> <b>2. Password:</b> Enter the password if applicable.<br /><br /><b>Draft (screen slides left and right) </b><br /> There are two ways to draft a player:<br /><br /><b>1. Switching through tabs:</b> Switch between different tabs to choose your different player(s).<br /><br /><b>2. Search for the name:</b> You can also search for the player(s) by their name. <br /><h6>Note: Once a player has been bought, you can't change it!</h6>";
		tabs.appendChild(join_tab);
	
	//Return to tabs to add to page
	return tabs;

}//End createTabs

// Enable tabs
$("#tabs-howToPlay").tabs();

function isTouchDevice() {
	try {
		document.createEvent("TouchEvent");
		return true;
	} catch (e) {
		return false;
	}
}

function touchScroll(id) {
	if(isTouchDevice()) { //if touch events exist...
		var el=document.getElementById(id);
		var scrollStartPos=0;

		document.getElementById(id).addEventListener("touchstart", function(event) {
			scrollStartPos=this.scrollTop+event.touches[0].pageY;
		},false);

		document.getElementById(id).addEventListener("touchmove", function(event) {
			this.scrollTop=scrollStartPos-event.touches[0].pageY;
		},false);
	}
}

touchScroll('tabs-scoring');
touchScroll('tabs-create');
touchScroll('tabs-join');