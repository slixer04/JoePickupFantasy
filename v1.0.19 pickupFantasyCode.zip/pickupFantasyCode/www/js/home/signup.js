var body = document.getElementById("contentWrapper");

// create elements
var signupHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var pass1Header = document.createElement("h2");
var pass2Header = document.createElement("h2");

var username = document.createElement("input");
var password1 = document.createElement("input");
var password2 = document.createElement("input");

var btn = document.createElement("button");

// set element attributes
username.type = "text";
password1.type = "password";
password2.type = "password";

username.id = "user";
password1.id = "pass1";
password2.id = "pass2";

signupHeader.innerHTML = "Sign up";
signupHeader.className = "underline";

userHeader.innerHTML = "Username:";
pass1Header.innerHTML = "Password:";
pass2Header.innerHTML = "Confirm Password:";


btn.innerHTML = "Sign up";
btn.className = "myButton";
btn.onclick = function() {
	if( (username.value == "") || (password1.value == "") || (password2.value=="") )
		alert("No fields can be left empty");
	else if(password1.value != password2.value) {
		alert("Passwords do not match");
	}
	else {
		// send GET request to server first to see if the username is taken
		var url = 'http://cryptic-waters-6734.herokuapp.com/users/'+username.value+'.json';
        var json = getRequest(url);

        // check to see if username is taken
        if(json != 0) {
        	alert("Username is already taken");
        }
        else {
        	// send POST request to server to add account
        	loading();
			var data = {
				user : {
					userID : "0",
					username : username.value,
					phoneCred : password1.value,
					won : "0",
					lost : "0",
					previousGamePlace : "0",
					leagueID : "0",
					rosterID : "0"
				}
			};

			// create account
			url = 'http://cryptic-waters-6734.herokuapp.com/users.json';
			var json = postRequest(url,data)
			if(json != 0) {
				alert("Successfully Created Account");
				localStorage["loggedIn"] = username.value + "," + json.id;
				location.reload();
			}
			else {
				alert("Failed to create account");
				notLoading();
			}
		}
	}
}



// add elements to page
body.appendChild(signupHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(document.createElement("br"));
body.appendChild(pass1Header);
body.appendChild(password1);
body.appendChild(document.createElement("br"));
body.appendChild(pass2Header);
body.appendChild(password2);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(btn);