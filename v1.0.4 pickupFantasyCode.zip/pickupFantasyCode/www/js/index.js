/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicity call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        parentElement.style.backgroundColor = "green";
        
        console.log('Received Event: ' + id);
    }
};

            function checkLogin() {

                var loggedIn = localStorage.getItem("loggedIn");
                var body = document.getElementById("deviceready");


                var logo = document.createElement("img");
                logo.src="img/introPlayer.png";
                logo.className = "footballPlayer";

                var wrapper = document.createElement("div");
                wrapper.id = "contentWrapper";

                if(loggedIn == null) {
                    //fill in lot logged in form
                    var userHeader = document.createElement("h2");
                    var passHeader = document.createElement("h2");

                    var username = document.createElement("input");
                    var password = document.createElement("input");

                    var login = document.createElement("button");
                    var sign = document.createElement("button");

                    userHeader.innerHTML = "Username:";
                    passHeader.innerHTML = "Password:";

                    username.type = "text";
                    username.id = "username";

                    password.type = "password";
                    password.id = "password";

                    login.innerHTML = "Log in!";
                    login.onclick = function() {
                        if((username.value == "test") && (password.value == "pass")) {
                            localStorage.setItem("loggedIn",true);
                            location.reload();
                        }
                        else {
                            alert("wrong credentials");
                        }
                    };

                    sign.innerHTML = "Sign up now!";
                    sign.className = "indent";
                    sign.onclick = function() {

                    };

                    body.appendChild(sign);
                    body.appendChild(logo);
                    body.appendChild(wrapper);

                    wrapper.appendChild(userHeader);
                    wrapper.appendChild(username);
                    wrapper.appendChild(passHeader); 
                    wrapper.appendChild(password);
                    wrapper.appendChild(document.createElement("br"));
                    wrapper.appendChild(document.createElement("br"));
                    wrapper.appendChild(login);
                    
                } else {
                    // fill in the logged in form
                    var create = document.createElement("button");
                    var join = document.createElement("button");
                    var view = document.createElement("button");
                    var logout = document.createElement("button");

                    create.innerHTML = "Create League";
                    join.innerHTML = "Join League";
                    view.innerHTML = "View League";
                    logout.innerHTML = "logout!";

                    create.onclick = function() {
                        window.location = "htmlPages/create/index.html";
                    };
                    join.onclick = function() {
                        window.location = "htmlPages/join/index.html";
                    };
                    view.onclick = function() {
                        window.location = "htmlPages/view/index.html";
                    };
                    logout.onclick = function() {
                        localStorage.removeItem("loggedIn");
                        location.reload();
                    };
                 
                    body.appendChild(logout);
                    body.appendChild(logo);
                    body.appendChild(wrapper);

                    wrapper.appendChild(create);
                    wrapper.appendChild(join);
                    wrapper.appendChild(view);
                }

            }


