setTimeout(notLoading(),1250);
var historyInfo =  localStorage["history"].split(",");
//alert("Wins: " + historyInfo[0] + "  Loses: " + historyInfo[1] + "  Previous Place: " + historyInfo[2]);
var body = document.getElementById("contentWrapper");

// fill in the logged in form
var userHistory = document.createElement("p");
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

create.innerHTML = "Create League";
create.className = "myButton";

join.innerHTML = "Join League";
join.className = "myButton";

view.innerHTML = "How to Play";
view.className = "myButton";

userHistory.innerHTML = "Wins: " + historyInfo[0] + "&nbsp;&nbsp; Loses: " + historyInfo[1] + "&nbsp;&nbsp; Previous Place: " + historyInfo[2];

create.addEventListener('touchstart',function() {
	showHome();
    loadScript("js/league/createLeague.js");
});
join.addEventListener('touchstart',function() {
	showHome();
    loadScript("js/league/joinLeague.js");
});
view.addEventListener('touchstart',function() {
	showHome();
	loadScript("js/home/howToPlay.js");
});

// add stylings for page                
body.style.textAlign = "center";
body.style.paddingTop = "80%";
body.style.marginLeft = "1%";

// add elements to page
body.appendChild(userHistory);
body.appendChild(create);
body.appendChild(join);
body.appendChild(view);