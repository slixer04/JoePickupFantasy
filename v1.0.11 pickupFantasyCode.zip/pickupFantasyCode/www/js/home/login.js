var body = document.getElementById("contentWrapper");

// create elements
var loginHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var username = document.createElement("input");
var password = document.createElement("input");

var login = document.createElement("button");

loginHeader.innerHTML = "Login";
loginHeader.className = "underline";

userHeader.innerHTML = "Username:";
passHeader.innerHTML = "Password:";

username.type = "text";
username.id = "username";

password.type = "password";
password.id = "password";

login.innerHTML = "Log in";
login.className = "myButton";
login.onclick = function() {
    if(username.value == "" || password.value == "") {
        alert("Username or password is empty");
    }
    else {
        loading();
        var req = new XMLHttpRequest();
        req.open('GET', 'http://cryptic-waters-6734.herokuapp.com/users/'+username.value+'.json', true);
        req.send();

        req.onreadystatechange = function() {
            if (req.readyState == 4) {
                if( (req.status == 200) || (req.status == 0) ) {

                    if(req.responseText.length > 0) {
                        var json = JSON.parse(req.responseText);
                        if(json.length > 0) {
                            if( (json[0].username == username.value) && (json[0].phoneCred == password.value) ){
                                        localStorage.setItem("loggedIn",username.value);
                                        localStorage.setItem("page","js/home/home.js");
                                        location.reload();
                            }
                            else {
                                alert("Invalid password");
                            }
                        }
                        else {
                            alert("Invalid username");
                        }
                    }
                    else {
                        alert("Error talking to the server");
                    }
                }
                else {
                    alert("Error talking to server");
                }
            }
            notLoading();
        }
    }
};

body.appendChild(loginHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(passHeader); 
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(login);
                    

function loading() {
    document.getElementById("blackout").style.display = 'block';
}
function notLoading() {
    document.getElementById("blackout").style.display = 'none';
}