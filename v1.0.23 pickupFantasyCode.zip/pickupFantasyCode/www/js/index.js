/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicity call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        parentElement.style.backgroundColor = "green";
        
        console.log('Received Event: ' + id);
    }
};

// FUNCTIONS JOE WROTE

function loadScript(src){
    clearElements();
    
    var e = document.createElement("script");
    e.src = src;
    e.type="text/javascript";
    document.getElementsByTagName("body")[0].appendChild(e);

    fadeIn(document.getElementById("contentWrapper"));
}
function clearElements() {
    document.getElementById("contentWrapper").innerHTML = "";
    document.getElementById("contentWrapper").style.opacity = 0;   

    document.getElementById("contentWrapper").style.textAlign = "left";
    document.getElementById("contentWrapper").style.paddingTop = "40%";
    document.getElementById("contentWrapper").style.marginLeft = "5%";
}

function fadeIn(element) { 
    var op = 0.01;  // initial opacity
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 25);
}

// will send a GET request to the parameter url
function getRequest(url) {
        var req = new XMLHttpRequest();
        req.open('GET', url, false);
        setHeaders(req);
        
        req.onreadystatechange = function() {
            if (req.readyState == 4) {
                if( (req.status == 200) || (req.status == 0) ) {
                    if( (typeof req.responseText != "undefined") && (req.responseText != "") ) {
                        localStorage["request"] = req.responseText;
                    }
                    else {
                        alert("GR-RT:"+req.responseText+". Error talking to the server");
                    }
                }
                else {
                    alert("GR-S:"+req.status+". Error talking to server");
                    localStorage["request"] = "-1";
                }
            }
            
        }

        req.send(null);
        return parseJSON();
}
// will send a post request to the parameter url with the data parameter
function postRequest(url, data) {
    
    var req = new XMLHttpRequest();
    req.open('POST', url, false);
    setHeaders(req);
        
    req.onreadystatechange = function() {
        if (req.readyState == 4) {
            if( (req.status == 200) || (req.status == 0) || (req.status == 201) ) {
                localStorage["request"] = req.responseText;
            } 
            else {
                alert("PSTR-S:"+req.status+". Error Talking to server");
            }
        }
    }

    req.send(JSON.stringify(data));
    return parseJSON();
}
function deleteRequest(url) {
    var req = new XMLHttpRequest();
    req.open('DELETE', url, false);
    setHeaders(req);
        
    req.onreadystatechange = function() {
        if (req.readyState == 4) {
            if( (req.status == 200) || (req.status == 0) || (req.status == 204) ) {
                localStorage["request"] = 1;
            }
            else {
                alert("DR-S:"+req.status+". Error talking to server");
            }
        }
    }

    req.send();
    return parseJSON();
}
// will send a put request to the parameter url with the data parameter
function putRequest(url, data) {
    
    var req = new XMLHttpRequest();
    req.open('PUT', url, false);
    setHeaders(req);
        
    req.onreadystatechange = function() {
        if (req.readyState == 4) {
            if( (req.status == 200) || (req.status == 0) || (req.status == 204) ) {
                localStorage["request"] = 1;
            } 
            else {
                alert("PR-S:"+req.status+". Error Talking to server");
            }
        }
    }

    req.send(JSON.stringify(data));
    return parseJSON();
}
function setHeaders(req) {
    req.setRequestHeader('Access-Control-Allow-Origin', 'http://cryptic-waters-6734.herokuapp.com');
    req.setRequestHeader("Content-Type","application/json");
    req.setRequestHeader("Accept","application/json");  
}
function parseJSON(){
    if(localStorage["request"] == "-1"){
        localStorage.removeItem("request");
        return -1;
    }
    else if(localStorage["request"]) {
        var json = localStorage["request"];
        localStorage.removeItem("request");
        return JSON.parse(json);
    }
    return 0;
    
}
                
// functions to make loading screen appear and disappear
function loading() {
    document.getElementById("blackout").style.display = 'block';
}
function notLoading() {
    document.getElementById("blackout").style.display = 'none';
}
function hideHome() {
    document.getElementById("home").style.display = 'none';
}
function showHome() {
    document.getElementById("home").style.display = 'block';
}

