var body = document.getElementById("contentWrapper");

function loadCSS(src){
    var fileref=document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", src);
    document.getElementsByTagName("head")[0].appendChild(fileref); 
}

loadCSS("css/home/login.css");

//fill in lot logged in form
var loginHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var username = document.createElement("input");
var password = document.createElement("input");

var login = document.createElement("button");

loginHeader.innerHTML = "Login";
loginHeader.className = "underline";
userHeader.innerHTML = "Username:";
passHeader.innerHTML = "Password:";

username.type = "text";
username.id = "username";

password.type = "password";
password.id = "password";

login.innerHTML = "Log in!";
login.onclick = function() {
    if((username.value == "test") && (password.value == "pass")) {
        localStorage.setItem("loggedIn",username.value);
        location.reload();
    } else {
        alert("wrong credentials");
    }
};

body.appendChild(loginHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(passHeader); 
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(login);
                    