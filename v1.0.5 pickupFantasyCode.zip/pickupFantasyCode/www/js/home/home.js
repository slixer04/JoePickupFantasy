var body = document.getElementById("contentWrapper");

function loadCSS(src){
    var fileref=document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", src);
    document.getElementsByTagName("head")[0].appendChild(fileref); 
}

loadCSS("css/home/home.css");

// fill in the logged in form
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

create.innerHTML = "Create League";
join.innerHTML = "Join League";
view.innerHTML = "View League";

create.onclick = function() {
    window.location = "htmlPages/create/index.html";
};
join.onclick = function() {
    window.location = "htmlPages/join/index.html";
};
view.onclick = function() {
    window.location = "htmlPages/view/index.html";
};
                 

body.appendChild(create);
body.appendChild(join);
body.appendChild(view);