var body = document.getElementById("contentWrapper");

// create elements
var signupHeader = document.createElement("h2");
var userHeader = document.createElement("h2");
var pass1Header = document.createElement("h2");
var pass2Header = document.createElement("h2");

var username = document.createElement("input");
var password1 = document.createElement("input");
var password2 = document.createElement("input");

var btn = document.createElement("button");

// set element attributes
username.type = "text";
password1.type = "password";
password2.type = "password";

username.id = "user";
password1.id = "pass1";
password2.id = "pass2";

signupHeader.innerHTML = "Sign up!";
signupHeader.className = "underline";

userHeader.innerHTML = "Username";
pass1Header.innerHTML = "Password:";
pass2Header.innerHTML = "Confirm Password:";


btn.innerHTML = "Sign up"
btn.onclick = function() {
	if( (username.value == "") || (password1.value == "") || (password2.value=="") )
		alert("No fields can be left empty");
	else if(password1.value != password2.value) {
		alert("Passwords do not match");
	}
	else {
		alert("confirm!\n\n Username: " + username.value + "\n Password:" + password1.value);
	}
}



// add elements to page
body.appendChild(signupHeader);
body.appendChild(userHeader);
body.appendChild(username);
body.appendChild(document.createElement("br"));
body.appendChild(pass1Header);
body.appendChild(password1);
body.appendChild(document.createElement("br"));
body.appendChild(pass2Header);
body.appendChild(password2);
body.appendChild(document.createElement("br"));
body.appendChild(document.createElement("br"));
body.appendChild(btn);