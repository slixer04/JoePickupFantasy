/* variables need for construction of header */
var header = document.getElementById("headerWrapper");
var loggedIn = localStorage.getItem("loggedIn");

/* constructing elements of the header */
var logo = document.createElement("img");
logo.src="img/introPlayer.png";
logo.className = "footballPlayer";


var logout = document.createElement("span");
logout.className = "logout";
if( (loggedIn == null) && (localStorage["page"] == "js/home/login.js") ) {
	logout.innerHTML = "Sign up";
	logout.onclick = function() {
		localStorage["page"] = "js/home/signup.js";
		location.reload();
	}
}
else if( (loggedIn == null) && (localStorage["page"] == "js/home/signup.js") ){
	logout.innerHTML = "Home";
	logout.onclick = function() {
		localStorage["page"] = "js/home/login.js";
		location.reload();
	}
}
else if( (loggedIn != null) && (localStorage["page"] != "js/home/home.js")) {
	var home = document.createElement("span");
	home.className = "left";
	home.innerHTML = "Home";
	home.onclick = function() {
		localStorage["page"] = "js/home/home.js";
		location.reload();
	}

	logout.innerHTML = "Log out";
	logout.onclick = function() {
		localStorage.removeItem("loggedIn");
		localStorage.setItem("page","js/home/login.js");
     	location.reload();
	}
	header.appendChild(home);
}
else {
	logout.innerHTML = "Log out";
	logout.onclick = function() {
		localStorage.removeItem("loggedIn");
		localStorage.setItem("page","js/home/login.js");
     	location.reload();
	}
}
header.appendChild(logout);
header.appendChild(logo);