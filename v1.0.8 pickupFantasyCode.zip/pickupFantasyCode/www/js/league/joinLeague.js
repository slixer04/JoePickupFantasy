var body = document.getElementById("contentWrapper");

// create elements
var joinHeader = document.createElement("h2");
var nameHeader = document.createElement("h2");
var passHeader = document.createElement("h2");

var leagueName = document.createElement("input");
var password = document.createElement("input");

var btn = document.createElement("button");

// set elements attributes
joinHeader.innerHTML = "Join League";
joinHeader.className = "underline";

nameHeader.innerHTML = "League Name:";
passHeader.innerHTML = "Password:";

leagueName.id = "leagueName";
leagueName.type="text";

password.id="password";
password.type="text";

btn.innerHTML = "Join";
btn.onclick = function() {
	localStorage["page"] = "js/league/createTeam.js";
    location.reload();
}

// add to document
body.appendChild(joinHeader);
body.appendChild(nameHeader);
body.appendChild(leagueName);
body.appendChild(passHeader);
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(btn);