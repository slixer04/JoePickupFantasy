/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicity call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        parentElement.style.backgroundColor = "green";
        
        console.log('Received Event: ' + id);
    }
};

// FUNCTIONS JOE WROTE

function loadScript(src){
    clearElements();
    
    var e = document.createElement("script");
    e.src = src;
    e.type="text/javascript";
    document.getElementsByTagName("body")[0].appendChild(e);

    fadeIn(document.getElementById("contentWrapper"));
}
function clearElements() {
    document.getElementById("contentWrapper").innerHTML = "";
    document.getElementById("contentWrapper").style.opacity = 0;   

    document.getElementById("contentWrapper").style.textAlign = "left";
    document.getElementById("contentWrapper").style.paddingTop = "40%";
    document.getElementById("contentWrapper").style.marginLeft = "5%";
}

function fadeIn(element) { 
    var op = 0.01;  // initial opacity
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 25);
}

// will send a GET request to the parameter url
// will return javascript json oject from url, or an empty array [] if there was no data
function getRequest(url) {
        loading();
        var req = new XMLHttpRequest();
        req.open('GET', url, false);
        
        req.onreadystatechange = function() {
            if (req.readyState == 4) {
                if( (req.status == 200) || (req.status == 0) ) {
                    if( (typeof req.responseText != "undefined") && (req.responseText != "") ) {
                        localStorage["get"] = req.responseText;
                    }
                    else {
                        alert("Error talking to the server");
                    }
                }
                else {
                    alert("Error talking to server");
                }
            }
            notLoading();
        }

        req.send();
        return parseJson();
}
function parseJson(){
    var json = localStorage["get"];
    localStorage.removeItem("get");
    return JSON.parse(json);
    
}

// will send a post request to the parameter url with the data parameter
// returns 1 if it was able to post to the ul, and 0 if it was not
function postRequest(url, data) {
    loading();
    var req = new XMLHttpRequest();
    req.open('POST', url, false);
    req.setRequestHeader('Access-Control-Allow-Origin', 'http://cryptic-waters-6734.herokuapp.com');
    req.setRequestHeader("Content-Type","application/json");
    req.setRequestHeader("Accept","application/json");
        
    req.onreadystatechange = function() {
        if (req.readyState == 4) {
            if( (req.status == 200) || (req.status == 0) || (req.status == 201) ) {
                localStorage["post"] = 1;
            }
        }
        else {
            alert("Error Talking to server");
        }
        notLoading();
    }

    req.send(JSON.stringify(data));
    return ifPosted();
}
function ifPosted(){
    if(localStorage["post"]){
        localStorage.removeItem("post");
        return 1;
    }
    else {
        return 0;
    }
}
                

function loading() {
    document.getElementById("blackout").style.display = 'block';
}
function notLoading() {
    document.getElementById("blackout").style.display = 'none';
}

