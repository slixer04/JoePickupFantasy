document.getElementById("contentWrapper").style.paddingTop = "80%";
document.getElementById("contentWrapper").style.textAlign = "center";

var header = document.createElement("h2");
header.innerHTML = "No internet connection.";
                        
var retry = document.createElement("p");
retry.innerHTML = "Retry?"
retry.addEventListener('touchstart',function() {
      location.reload();
});

document.getElementById("contentWrapper").appendChild(header);
document.getElementById("contentWrapper").appendChild(retry);