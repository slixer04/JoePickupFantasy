var leagueInfo = localStorage["leagueInfo"].split(",");
var userInfo = localStorage["loggedIn"].split(",");

account = {
    wins: 0,
    losses: 0,
    prvPlace: 0 
}

test = {
    usersTable: [{"id":12,"userID":0,"username":"joe","phoneCred":"1","won":6,"lost":2,"previousGamePlace":1,"leagueName":"CAP LETTER TEST","rosterID":43,"url":"http://cryptic-waters-6734.herokuapp.com/users/12.json"},
                    {"id":19,"userID":0,"username":"ank","phoneCred":"123","won":0,"lost":0,"previousGamePlace":0,"leagueName":"","rosterID":0,"url":"http://cryptic-waters-6734.herokuapp.com/users/19.json"},
                    {"id":28,"userID":0,"username":"adp6y","phoneCred":"1","won":0,"lost":0,"previousGamePlace":0,"leagueName":"","rosterID":0,"url":"http://cryptic-waters-6734.herokuapp.com/users/28.json"},
                    {"id":29,"userID":0,"username":"JoeLoser","phoneCred":"test","won":0,"lost":0,"previousGamePlace":0,"leagueName":"","rosterID":0,"url":"http://cryptic-waters-6734.herokuapp.com/users/29.json"}
                ]
}

createViewAccountPage();

function createViewAccountPage()
{
    findAccountInformation(getAccountInformation());

    var body = document.getElementById("contentWrapper");

        var header = document.createElement("h2");
        header.innerHTML = "<u>View User Account<u>";
        header.style.textAlign = "center";
        header.style.marginTop = "8%";

    body.appendChild(header);

        var loggedIn = document.createElement("p");
        loggedIn.innerHTML = "Logged in as:";
        loggedIn.style.textAlign = "center";
        loggedIn.style.marginBottom = "-4%";

    body.appendChild(loggedIn);

        var user = document.createElement("p");
        user.innerHTML = "<b>" + userInfo[0] + "<b>";
        user.style.textAlign = "center";
        user.style.fontSize = "150%";

    body.appendChild(user);

        var prvHeader = document.createElement("p");
        prvHeader.innerHTML = "Previous League Place:";
        prvHeader.style.textAlign = "center";
        prvHeader.style.marginBottom = "-4%";

    body.appendChild(prvHeader);

        var prvPlace = document.createElement("p");
        prvPlace.innerHTML = "<b>" + placeString(account.prvPlace) + "<b>";
        prvPlace.style.textAlign = "center";
        prvPlace.style.fontSize = "150%";

    body.appendChild(prvPlace);

        var recHeader = document.createElement("p");
        recHeader.innerHTML = "Record (W - L):";
        recHeader.style.textAlign = "center";
        recHeader.style.marginBottom = "-4%";

    body.appendChild(recHeader);

        var record = document.createElement("p");
        record.innerHTML = "<b>" + account.wins + " - " + account.losses + "<b>";
        record.style.textAlign = "center";
        record.style.fontSize = "150%";

    body.appendChild(record);
}

//Return place string
function placeString(place)
{
    if(place == 0)
        return "X";
    else if (place == 1)
        return "1st";
    else if (place == 2)
        return "2nd";
    else if (place == 3)
        return "3rd";
    else 
        return place + "th";
}

//Find the logged in users information
function findAccountInformation(users)
{
    //Go through list of league members
    for(var i = 0; i < users.length; i++)
    {
        if(users[i].username == userInfo[0])
        {
            account.wins = users[i].won;
            account.losses = users[i].lost;
            account.prvPlace = users[i].previousGamePlace;
            break;
        }
    }
}

//Get account information
function getAccountInformation()
{
    //return test.usersTable;
    var URL = "http://cryptic-waters-6734.herokuapp.com/users.json";
    var json = getRequest(URL);
    return json;
}