setTimeout(notLoading(),1250);

var historyInfo =  localStorage["history"].split(",");
var userInfo = localStorage["loggedIn"].split(",");

//alert("Wins: " + historyInfo[0] + "  Loses: " + historyInfo[1] + "  Previous Place: " + historyInfo[2]);
var body = document.getElementById("contentWrapper");

// fill in the logged in form
var userHeader = document.createElement("h2");
var userHistory = document.createElement("p");
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

userHeader.innerHTML = userInfo[0];

userHistory.innerHTML = "Wins: " + historyInfo[0] + "&nbsp;&nbsp; Loses: " + historyInfo[1] + "&nbsp;&nbsp; Previous Place: " + placeString(historyInfo[2]);

create.innerHTML = "Create League";
create.className = "myButton";

join.innerHTML = "Join League";
join.className = "myButton";

view.innerHTML = "How to Play";
view.className = "myButton";

create.addEventListener('touchstart',function() {
	showHome();
    loadScript("js/league/createLeague.js");
});
join.addEventListener('touchstart',function() {
	showHome();
    loadScript("js/league/joinLeague.js");
});
view.addEventListener('touchstart',function() {
	showHome();
	loadScript("js/home/howToPlay.js");
});

// add stylings for page                
body.style.textAlign = "center";
body.style.paddingTop = "60%";
body.style.marginLeft = "1%";

// add elements to page
body.appendChild(userHeader);
body.appendChild(userHistory);
body.appendChild(create);
body.appendChild(join);
body.appendChild(view);


//Return place string
function placeString(place)
{
    if(place == 0)
        return "X";
    else if (place == 1)
        return "1st";
    else if (place == 2)
        return "2nd";
    else if (place == 3)
        return "3rd";
    else 
        return place + "th";
}