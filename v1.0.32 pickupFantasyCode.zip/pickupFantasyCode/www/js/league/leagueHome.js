//Global variables
var leagueInfo = localStorage["leagueInfo"].split(",");
league = {
	userLeagueid: 0,
	memberInfo: [],
	playerInfo: [],	//Holds {"NFLPlayerID": , "FantasyPoints": , "FirstName": , "LastName": , "FantasyPosition":, "CurrentTeam": }
	playerIds: []
}

// Test data
test = {
	connected: true,
	Leagueid: 4,
	rosters: [{"id":6,"rosterID":0,"username":"joco","leagueID":4,"qb":4097,"flex":1181,"k":12594,"wr":11667,"rb":2699,"url":"http://cryptic-waters-6734.herokuapp.com/rosters/6.json"},
				{"id":7,"rosterID":0,"username":"newbie","leagueID":4,"qb":4932,"flex":1181,"k":1410,"wr":11667,"rb":2699,"url":"http://cryptic-waters-6734.herokuapp.com/rosters/7.json"},			
				{"id":10,"rosterID":0,"username":"wild","leagueID":4,"qb":4097,"flex":4484,"k":12594,"wr":13460,"rb":12386,"url":"http://cryptic-waters-6734.herokuapp.com/rosters/10.json"},				
				{"id":12,"rosterID":0,"username":"joe","leagueID":4,"qb":4932,"flex":4484,"k":1410,"wr":13460,"rb":12386,"url":"http://cryptic-waters-6734.herokuapp.com/rosters/12.json"}
			],
	playerStats: [ {"id":810,"NFLPlayerID":4932,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":10,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":732,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":5,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":1652,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":0,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":13788,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":2,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":9108,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":1,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},				
				{"id":810,"NFLPlayerID":4097,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":1,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":12273,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":3,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":9079,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":2,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":4484,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":4,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":12594,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":5,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":12386,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":12,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":13460,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":10,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":1269,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":9,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":11667,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":19,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":8529,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":23,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":3388,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":3,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":9999,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":30,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":2699,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":20,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},				
				{"id":810,"NFLPlayerID":1181,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":9,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":1410,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":2,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":7328,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":15,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":11488,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":9,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":549,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":0,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":11197,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":3,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"},
				{"id":810,"NFLPlayerID":11932,"SlotID":"0700001","CurrentAuctionValue":0,"FantasyPoints":5,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/810.json"}
			],
	playerInfo: [{"id":1,"NFLPlayerID":4932,"cbsID":0,"nerdID":0,"CurrentTeam":"ATL","FantasyPosition":"QB","Number":2,"FirstName":"Matt","LastName":"Ryan","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":2699,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"RB","Number":2,"FirstName":"Taylor","LastName":"Homoky","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":11667,"cbsID":0,"nerdID":0,"CurrentTeam":"NYG","FantasyPosition":"WR","Number":2,"FirstName":"Ankil","LastName":"Patel","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":13460,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"WR","Number":2,"FirstName":"Tyler","LastName":"Seguin","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":4484,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"RB","Number":2,"FirstName":"Trevor","LastName":"Daley","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":12594,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"K","Number":2,"FirstName":"BIll","LastName":"Bill","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":1181,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"TE","Number":2,"FirstName":"Clayton","LastName":"Sussman","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":1410,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"K","Number":2,"FirstName":"Billy","LastName":"Joe","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":4097,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"QB","Number":2,"FirstName":"Mike","LastName":"Modano","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
				{"id":1,"NFLPlayerID":12386,"cbsID":0,"nerdID":0,"CurrentTeam":"DAL","FantasyPosition":"RB","Number":2,"FirstName":"Jamie","LastName":"Benn","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"},
			]
}


/*LEAGUE HOME PAGE STARTS HERE */
createLeaguePage();
setTimeout(notLoading,3000);


/* DISPLAY PAGE / CREATE TABLES */

//Creates the page
function createLeaguePage()
{
	//Get users leagueId from the cookies
	getUserLeagueid();

	//Create reference to the contentWrapper on the page
	var body = document.getElementById("contentWrapper");	

		//Display CurrentLeague Name
		var leagueNameHeader = document.createElement("h2");
		leagueNameHeader.setAttribute("id", "teamName");
		leagueNameHeader.innerHTML = leagueInfo[0];
		leagueNameHeader.style.textAlign = "center";
		leagueNameHeader.style.marginTop = "7%";
		leagueNameHeader.style.marginBottom = "2%";
		body.appendChild(leagueNameHeader);

		//Display Link to users account
		var viewAccount = document.createElement("a");
		viewAccount.className = "howToPlayButton";
		viewAccount.innerHTML = "Click for Account History.";
		viewAccount.style.textAlign = "center";
		viewAccount.style.width = "45%";
		viewAccount.style.marginBottom = "2%";
		viewAccount.style.marginLeft = $(window).width() * .23 + "px";
		viewAccount.addEventListener('touchstart',function(){ 
			goToViewAccount()
		});


		body.appendChild(viewAccount);

		//Create Container for league members
		var leagueContainer = document.createElement("div");
		leagueContainer.setAttribute("id", "leagueContainer");
		leagueContainer.style.width = "97%";		
		leagueContainer.style.border = "4px solid white";
		leagueContainer.style.borderRadius = "15px";
		leagueContainer.style.background = "Gray";
		leagueContainer.appendChild(createLeagueTable());
			var newHeight = ($(window).height()*.07) + (($(window).height()*.09) * league.memberInfo.length)
		leagueContainer.style.height = newHeight + "px";

	body.appendChild(leagueContainer);
		
		//Create update score button
		var update_btn = document.createElement("a");
		update_btn.className = "updateButton";
		update_btn.style.marginLeft = $(window).width() * .24 + "px";
		update_btn.style.width = "40%";
		update_btn.innerHTML = "Update Scores";
		update_btn.addEventListener('touchstart',function()	{
			loading();
			setTimeout(update(),500);
		});									
		
	body.appendChild(update_btn);


	var howToPlay = document.createElement("a");
	howToPlay.className = "howToPlayButton";
	howToPlay.innerHTML = "View Scoring System?";
	howToPlay.style.textAlign = "center";
	howToPlay.style.width = "40%";
	howToPlay.style.marginLeft = $(window).width() * .24 + "px";
	howToPlay.addEventListener('touchstart',function()	{
		goToHowToPlay()
	});


	body.appendChild(howToPlay);
}

//Creates the member League table 
function createLeagueTable()
{
	//Update the players scores if connected to the internet

	//Filter league members and save player ids
	var json = getLeagueInfo();
	if( (json != 0) && (json != -1) ){
		filterRosterList(json);
		updateTeamScores();
	}
	else {
		alert("Not connected to the internet!");
	}

		//Update the members team scores
	//If member info doesnt already exsit
	if( league.memberInfo.length == 0)
	{
		var text = document.createElement("h3")
		text.innerHTML = "Not connected to the internet!";	//leagueInfo[0];
		text.style.textAlign = "center";
		text.style.marginTop = "4%";
		return	text;
	}

	//Sort league members scores
	league.memberInfo.sort(function (a,b) {
		if ( a.rosterID < b.rosterID)
			return 1;
		if ( a.rosterID > b.rosterID)
			return -1;
		return 0;
	});

	//Create league table team
	var leagueTbl = document.createElement("table");
	leagueTbl.setAttribute("id", "leagueTeamTable");
	leagueTbl.style.marginTop = Math.max(league.memberInfo.length/2, 1) + "%";
	leagueTbl.setAttribute('border', '3');

		//Create table body
		var tblBody = document.createElement("tbody");
			//Create Header row
			var tblHeader = document.createElement("tr");
			tblHeader.setAttribute("id", "leagueTableRowHeader");
			tblHeader.style.height = "14%";
				//Create FantasyPosition column
				var header_pos = document.createElement("td");
				header_pos.style.width = "20%";
				header_pos.appendChild(document.createTextNode("Rank"));
				tblHeader.appendChild(header_pos);
				//Create name column
				var header_nme = document.createElement("td");
				header_nme.style.width = "60%";
				header_nme.appendChild(document.createTextNode("League Members"));
				tblHeader.appendChild(header_nme);
				//Create CurrentAuctionValue column
				var header_val = document.createElement("td");
				header_val.style.width = "20%";
				header_val.appendChild(document.createTextNode("Score"));
				tblHeader.appendChild(header_val);
			//Add header row to table
			tblBody.appendChild(tblHeader);

			//Create a row for each memeber in the league
			for( var i = 0; i < league.memberInfo.length; i++)
			{
				//Create member row
				var tblMemberRow = document.createElement("tr");
				tblMemberRow.setAttribute("id", league.memberInfo[i].username + "Row");
				tblMemberRow.style.textAlign = "center";
				tblMemberRow.style.fontSize = "130%";
				
					//Create Team number column
					var team_pos = document.createElement("td");
					team_pos.appendChild(document.createTextNode("# " + (i + 1)));
					tblMemberRow.appendChild(team_pos);
					//Create Member name column
					var member_nme = document.createElement("td");
					member_nme.className = "memeberTableName";
						var name = document.createElement("a");
						name.className = "Link";
						name.innerHTML = league.memberInfo[i].username;
						name.setAttribute("href", "javascript:viewTeamStats('" + league.memberInfo[i].username + "')");	
					member_nme.appendChild(name);					
					tblMemberRow.appendChild(member_nme);
					//Create Memebers current score
					var member_score = document.createElement("td");
					member_score.setAttribute("id", league.memberInfo[i].username + "Score");
						var score = document.createElement("a");
						score.className = "Link";
						score.innerHTML = league.memberInfo[i].rosterID; 	//RosterID used to hold the team score
						score.setAttribute("href", "javascript:viewTeamStats('" + league.memberInfo[i].username + "')");	
					member_score.appendChild(score);	//RosterID used to hold team score
					tblMemberRow.appendChild(member_score);
				//Add QB row to table
				tblBody.appendChild(tblMemberRow);
			}		

		//Add data of table to the table
		leagueTbl.appendChild(tblBody);
	return leagueTbl;
}

//Create table to display users rosters
function displayRosterTable(qb_index, rb_index, wr_index, flex_index, k_index)
{
	//Create table body
	var tblBody = document.createElement("tbody");

		//Create Header row
		var tblHeader = document.createElement("tr");
		tblHeader.style.textAlign = "center";
		tblHeader.style.height = "20%";
		tblHeader.style.fontWeight = "bold";
			//Create FantasyPosition column
			var header_pos = document.createElement("td");
			header_pos.style.width = "10%";
			header_pos.appendChild(document.createTextNode("Pos."));
			tblHeader.appendChild(header_pos);
			//Create name column
			var header_nme = document.createElement("td");
			header_nme.style.width = "80%";
			header_nme.appendChild(document.createTextNode("Name"));
			tblHeader.appendChild(header_nme);
			//Create CurrentAuctionValue column
			var header_val = document.createElement("td");
			header_val.style.width = "10%";
			header_val.appendChild(document.createTextNode("Pts"));
			tblHeader.appendChild(header_val);
		//Add header row to table
		tblBody.appendChild(tblHeader);
		//Create QB row
		var qbRow = document.createElement("tr");
			//Create FantasyPosition column
			var pos = document.createElement("td");
			pos.appendChild(document.createTextNode("QB:"));
			qbRow.appendChild(pos);
			//Create name column
			var nme = document.createElement("td");
			nme.style.fontSize = "90%";
			nme.className = "overflowName";
			nme.innerHTML = "(" + league.playerInfo[qb_index].CurrentTeam + ") " + league.playerInfo[qb_index].LastName + ", " + league.playerInfo[qb_index].FirstName;			
			qbRow.appendChild(nme);
			//Create Current points column
			var points = document.createElement("td");
			points.style.fontWeight = "bold";
			points.appendChild(document.createTextNode(league.playerInfo[qb_index].FantasyPoints));
			qbRow.appendChild(points);
		//Add header row to table
		tblBody.appendChild(qbRow);
		//Create RB row
		var rbRow = document.createElement("tr");
			//Create FantasyPosition column
			var pos = document.createElement("td");
			pos.appendChild(document.createTextNode("RB:"));
			rbRow.appendChild(pos);
			//Create name column
			var nme = document.createElement("td");
			nme.style.fontSize = "90%";
			nme.className = "overflowName";
			nme.innerHTML = "(" + league.playerInfo[rb_index].CurrentTeam + ") " + league.playerInfo[rb_index].LastName + ", " + league.playerInfo[rb_index].FirstName;			
			rbRow.appendChild(nme);
			//Create Current points column
			var points = document.createElement("td");
			points.style.fontWeight = "bold";
			points.appendChild(document.createTextNode(league.playerInfo[rb_index].FantasyPoints));
			rbRow.appendChild(points);
		//Add header row to table
		tblBody.appendChild(rbRow);
		//Create WR row
		var wrRow = document.createElement("tr");
			//Create FantasyPosition column
			var pos = document.createElement("td");
			pos.appendChild(document.createTextNode("WR:"));
			wrRow.appendChild(pos);
			//Create name column
			var nme = document.createElement("td");
			nme.style.fontSize = "90%";
			nme.className = "overflowName";
			nme.innerHTML = "(" + league.playerInfo[wr_index].CurrentTeam + ") " + league.playerInfo[wr_index].LastName + ", " + league.playerInfo[wr_index].FirstName;			
			wrRow.appendChild(nme);
			//Create Current points column
			var points = document.createElement("td");
			points.style.fontWeight = "bold";
			points.appendChild(document.createTextNode(league.playerInfo[wr_index].FantasyPoints));
			wrRow.appendChild(points);
		//Add header row to table
		tblBody.appendChild(wrRow);
		//Create Flex row
		var flexRow = document.createElement("tr");
			//Create FantasyPosition column
			var pos = document.createElement("td");
			pos.appendChild(document.createTextNode("Flex:"));
			flexRow.appendChild(pos);
			//Create name column
			var nme = document.createElement("td");
			nme.style.fontSize = "90%";
			nme.className = "overflowName";
			nme.innerHTML = "(" + league.playerInfo[flex_index].CurrentTeam + ") " + league.playerInfo[flex_index].LastName + ", " + league.playerInfo[flex_index].FirstName;			
			flexRow.appendChild(nme);
			//Create Current points column
			var points = document.createElement("td");
			points.style.fontWeight = "bold";
			points.appendChild(document.createTextNode(league.playerInfo[flex_index].FantasyPoints));
			flexRow.appendChild(points);
		//Add header row to table
		tblBody.appendChild(flexRow);
		//Create K row
		var kRow = document.createElement("tr");
			//Create FantasyPosition column
			var pos = document.createElement("td");
			pos.appendChild(document.createTextNode("K:"));
			kRow.appendChild(pos);
			//Create name column
			var nme = document.createElement("td");
			nme.style.fontSize = "90%";
			nme.className = "overflowName";
			nme.innerHTML = "(" + league.playerInfo[k_index].CurrentTeam + ") " + league.playerInfo[k_index].LastName + ", " + league.playerInfo[k_index].FirstName;			
			kRow.appendChild(nme);
			//Create Current points column
			var points = document.createElement("td");
			points.style.fontWeight = "bold";
			points.appendChild(document.createTextNode(league.playerInfo[k_index].FantasyPoints));
			kRow.appendChild(points);
		//Add header row to table
		tblBody.appendChild(kRow);
	return tblBody;
}

//Filter league members and save player ids
function filterRosterList(rosterList)
{
	//Clear list of members for new additional members that have joined
	league.memberInfo = [];

	//Go through list of league members
	for(var i = 0; i < rosterList.length; i++)
	{
		//If the leagueid matches the logged leagueId save the user
		if(rosterList[i].leagueID == league.userLeagueid)
		{
			//Save member info
			league.memberInfo.push(rosterList[i]);

			//Save active the active playerIds in this league
			if(league.playerIds.indexOf(rosterList[i].qb) == -1)
			{
				//Save player NFLPlayerID 						//playerIds and playerInfo have the same indexing
				league.playerIds.push(rosterList[i].qb);
				//Create JSON to link player ID and points to save on the phone
				league.playerInfo.push({"NFLPlayerID": rosterList[i].qb, "FantasyPoints" : 0, "FirstName": "-", "LastName": "-", "FantasyPosition": "-", "CurrentTeam": "-"});
			}
			if(league.playerIds.indexOf(rosterList[i].rb) == -1)
			{
				league.playerIds.push(rosterList[i].rb);
				league.playerInfo.push({"NFLPlayerID": rosterList[i].rb, "FantasyPoints" : 0, "FirstName": "-", "LastName": "-", "FantasyPosition": "-", "CurrentTeam": "-"});
			}
			if(league.playerIds.indexOf(rosterList[i].wr) == -1)
			{
				league.playerIds.push(rosterList[i].wr);
				league.playerInfo.push({"NFLPlayerID": rosterList[i].wr, "FantasyPoints" : 0, "FirstName": "-", "LastName": "-", "FantasyPosition": "-", "CurrentTeam": "-"});
			}
			if(league.playerIds.indexOf(rosterList[i].flex) == -1)
			{
				league.playerIds.push(rosterList[i].flex);
				league.playerInfo.push({"NFLPlayerID": rosterList[i].flex, "FantasyPoints" : 0, "FirstName": "-", "LastName": "-", "FantasyPosition": "-", "CurrentTeam":"-"});
			}	
			if(league.playerIds.indexOf(rosterList[i].k) == -1)
			{
				league.playerIds.push(rosterList[i].k);
				league.playerInfo.push({"NFLPlayerID": rosterList[i].k, "FantasyPoints" : 0, "FirstName": "-", "LastName": "-", "FantasyPosition": "-", "CurrentTeam": "-"});
			}
		}
	}

	//Updates the teams players name and position information
	updatePlayerInfo(getPlayerInfo());
}

//View team stats
function viewTeamStats(memeberName)
{
	
	//Loop through to find the players for this members team
	for( var i = 0; i < league.memberInfo.length; i++)
	{
		if(league.memberInfo[i].username == memeberName)
		{
			var qb_index = league.playerIds.indexOf(league.memberInfo[i].qb);
			var rb_index = league.playerIds.indexOf(league.memberInfo[i].rb);
			var wr_index = league.playerIds.indexOf(league.memberInfo[i].wr);
			var flex_index = league.playerIds.indexOf(league.memberInfo[i].flex);
			var k_index = league.playerIds.indexOf(league.memberInfo[i].k);
			
			/*alert("QB: " + league.playerInfo[qb_index].FirstName + " " + league.playerInfo[qb_index].LastName);
			alert("RB: " + league.playerInfo[rb_index].FirstName + " " + league.playerInfo[rb_index].LastName);
			alert("WR: " + league.playerInfo[wr_index].FirstName + " " + league.playerInfo[wr_index].LastName);
			alert("FX: " + league.playerInfo[flex_index].FirstName + " " + league.playerInfo[flex_index].LastName);
			alert("K: " + league.playerInfo[k_index].FirstName + " " + league.playerInfo[k_index].LastName);
			*/

			var body = document.getElementById("contentWrapper");
				var popUp = document.createElement("div");
				popUp.setAttribute("id", "dialog-message");
				popUp.setAttribute("title", league.memberInfo[i].username + "'s Roster");
				popUp.appendChild(displayRosterTable(qb_index, rb_index, wr_index, flex_index, k_index));
			body.appendChild(popUp);

			$("#dialog-message").dialog({
				modal: true,
				buttons: {
					Ok: function() {
						$(this).dialog("close");
					}
				}
			});

			break;
		}
	}
}


/* UPDATE PLAYER STATS AND MEMBER TEAM STATS */

//Update league members and player scores
function update()
{	
	//TEST ADDING A NEW USER
	//test.rosters.push({"id":12,"rosterID":0,"username":"joe9","leagueID":4,"qb":4932,"flex":4484,"k":1410,"wr":13460,"rb":12386,"url":"http://cryptic-waters-6734.herokuapp.com/rosters/12.json"});
 
	//If connected to the internet
	loading();

	//Update page with new memebers
	var currPage = document.getElementById("contentWrapper");
	currPage.innerHTML = "";
	createLeaguePage();
	
	setTimeout(notLoading,1000);
}

//Update the member's team scores
function updateTeamScores()
{							
	updatePlayerPoints(getPlayerStats());

	for( var i = 0; i < league.memberInfo.length; i++)
	{
		var newScore = 0;
			//Add qb score
			var qb_index = league.playerIds.indexOf(league.memberInfo[i].qb);
				newScore += league.playerInfo[qb_index].FantasyPoints;
			//Add rb score
			var rb_index = league.playerIds.indexOf(league.memberInfo[i].rb);
				newScore += league.playerInfo[rb_index].FantasyPoints;
			//Add wr score
			var wr_index = league.playerIds.indexOf(league.memberInfo[i].wr);
				newScore += league.playerInfo[wr_index].FantasyPoints;
			//Add flex score
			var flex_index = league.playerIds.indexOf(league.memberInfo[i].flex);
				newScore += league.playerInfo[flex_index].FantasyPoints;
			//Add k score
			var k_index = league.playerIds.indexOf(league.memberInfo[i].k);
				newScore += league.playerInfo[k_index].FantasyPoints;

		//Save new score for member under RosterID (Using rosterID as team score)
		league.memberInfo[i].rosterID = newScore;
	}
}

//Update players scores
function updatePlayerPoints(playerList)
{
	//Go through list of players
	for( var i = 0; i < playerList.length; i++)
	{
		//If player is a player on a members team
		if(league.playerIds.indexOf(playerList[i].NFLPlayerID) != -1)
		{
			//Player ids and playerInfo have the same indexing
			var index = league.playerIds.indexOf(playerList[i].NFLPlayerID);
			league.playerInfo[index].FantasyPoints = playerList[i].FantasyPoints;
		}
	}
}

//Update player info
function updatePlayerInfo(playerList)
{
	//Go through list of players
	for(var i = 0; i < playerList.length; i++)
	{
		//If the player is on a members team
		if(league.playerIds.indexOf(playerList[i].NFLPlayerID) != -1)
		{
			//Save info
			var index = league.playerIds.indexOf(playerList[i].NFLPlayerID);
			league.playerInfo[index].FirstName = playerList[i].FirstName; 
			league.playerInfo[index].LastName = playerList[i].LastName; 
			league.playerInfo[index].FantasyPosition = playerList[i].FantasyPosition;
			league.playerInfo[index].CurrentTeam = playerList[i].CurrentTeam;  
		}
	}
}



/* MAKE API CALLS */

//Gets member names and team player playerIds
function getLeagueInfo()
{
	//return test.rosters;	//Get roster table
	var URL = "http://cryptic-waters-6734.herokuapp.com/rosters.json";
	var json = getRequest(URL);
	return json;
}

//Get users leagueId from the cookies
function getUserLeagueid()
{
	league.userLeagueid = leagueInfo[1];	//Get league id from cookies
}

//Get player's game stat data "currentFantasy Points"
function getPlayerStats()
{
	//return test.playerStats;	//Week Player data table
	var URL = "http://cryptic-waters-6734.herokuapp.com/weekplayerdata.json";
	var json = getRequest(URL);
	return json;
}

//Get the players info "names, positions"
function getPlayerInfo()
{
	//return test.playerInfo;		//Get Season Player data table
	var URL = "http://cryptic-waters-6734.herokuapp.com/seasonplayerdata.json";
	var json = getRequest(URL);
	return json;
}

//Send user to how to play
function goToHowToPlay()
{
showHome();
loadScript("js/home/howToPlay.js");
}


//Send user to how to play
function goToViewAccount()
{
showHome();
loadScript("js/home/viewAccount.js");
}