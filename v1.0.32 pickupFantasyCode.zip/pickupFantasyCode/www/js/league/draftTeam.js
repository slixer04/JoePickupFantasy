setTimeout(loading,1);
var userInfo = localStorage["loggedIn"].split(",");
var leagueInfo = localStorage["leagueInfo"].split(",");

/* Position Enumeration:*/
posEnum = {
	empty: -1,
	qb: 'QB',
	rb: 'RB',
	wr: 'WR',
	te: 'TE',
	k: 'K',	
	searched: 5
};
/*Time slots Enumeration:*/
timeSlot = {
	thur: '10000',
	sun1: '01000',
	sun2: '00100',
	sun3: '00010',
	mon: '00001'
};
/* Draft namespace not to clash with other pages variables */
draft = {
	teamBudget: 100,
	qb_nme_selected: 'undrafted',
	qb_val_selected: 0,
	qb_id_selected: posEnum.empty,
	rb_nme_selected: 'undrafted',
	rb_val_selected: 0,
	rb_id_selected: posEnum.empty,
	wr_nme_selected: 'undrafted',
	wr_val_selected: 0,
	wr_id_selected: posEnum.empty,
	flex_nme_selected: 'undrafted',
	flex_val_selected:  0,
	flex_id_selected: posEnum.empty,
	k_nme_selected: 'undrafted',
	k_val_selected: 0,
	k_id_selected: posEnum.empty,
	qbPlayerList: [],
	rbPlayerList: [],
	wrPlayerList: [],
	tePlayerList: [],
	kPlayerList: [],
	playerIDList: [],
	playablePlayerList: [],
	searchPlayerList: [],
	thurTimeCheck: null,
	sun1TimeCheck: null,
	sun2TimeCheck: null,
	sun3TimeCheck: null,
	monTimeCheck: null
};
/* Test data */
test = {
	gameSlota: "01110",
	gameSlotb: "10000",
	gameSlotc: "00001",
	playerList: [{"id":1,"NFLPlayerID":732,"cbsID":0,"nerdID":0,"CurrentTeam":"ATL","FantasyPosition":"QB","Number":2,"FirstName":"Matt","LastName":"Ryan","InitialAuctionValue":15,"CurrentAuctionValue":15,"projFantasyPoints":0,"projFantasyPointsMark":0,"LastPlayedPoints":0,"url":"http://cryptic-waters-6734.herokuapp.com/seasonplayerdata/1.json"}],
	timeSlotList: [{"id":1,"NFLPlayerID":732,"SlotID":"0910000","CurrentAuctionValue":15,"FantasyPoints":0,"Passyds":0,"Rushyds":0,"Rcvyds":0,"Fumbles":0,"TDPass":0,"TwoPointPass":0,"TwoPointRush":0,"TDRush":0,"TDRcv":0,"TwoPointRcv":0,"ExtraPoint":0,"FieldGoal":0,"url":"http://cryptic-waters-6734.herokuapp.com/weekplayerdata/1.json"}]
}

/*DRAFT PAGE STARTS HERE */

//Called to create the draft page
setTimeout(createDraftPage(),500);
setTimeout(notLoading,3000);

/* Function Decelerations */


/* CREATE PAGE functions */

//Creates the Draft Page
function createDraftPage()
{
	//Create reference to the contentWrapper on the page
	var body = document.getElementById("contentWrapper");
	body.style.paddingTop = "45%";
	body.style.maxHeight = "55%";

		//Display CurrentTeam Name
		var teamNameHeader = document.createElement("h2");
		teamNameHeader.setAttribute("id", "teamName");
		teamNameHeader.innerHTML = leagueInfo[0] + "'s Draft Room";
		teamNameHeader.style.textAlign = "center";
		teamNameHeader.style.marginBottom = "-3%";
		body.appendChild(teamNameHeader);
		
		//Display Draft Budget
		var teamDraftBudget = document.createElement("p");
		teamDraftBudget.setAttribute("id", "budget");
		teamDraftBudget.style.textAlign = "center";
		teamDraftBudget.innerHTML = "Remaining Draft Budget: $" + draft.teamBudget;
		body.appendChild(teamDraftBudget);
		
		//Create Container for swiping pages
		var swipperContainer = document.createElement("div");
		swipperContainer.className = "swiper-container";
		swipperContainer.style.width = "97%";
		swipperContainer.style.height = $(window).height()*.59 + "px";
		swipperContainer.style.border = "4px solid white";
		swipperContainer.style.borderRadius = "15px";

			//Create Wrapper for swipping pages
			var swipperWrapper = document.createElement("div");
			swipperWrapper.className = "fullSize";
			swipperWrapper.className = "swiper-wrapper";

				//Page 1 - Draft team
				var swipperSlide1 = document.createElement("div");				
				swipperSlide1.className = "fullSize";
				swipperSlide1.className = "swiper-slide";
				swipperSlide1.style.borderRadius = "10px";
				swipperSlide1.style.background = "Gray";				
				swipperSlide1.appendChild(createTeamTable());	//Create team table on page 1
																										
				swipperWrapper.appendChild(swipperSlide1);
				
				//Page 2 - Search by FantasyPosition
				var swipperSlide2 = document.createElement("div");
				swipperSlide2.className = "fullSize";
				swipperSlide2.className = "swiper-slide";
				swipperSlide2.style.borderRadius = "10px";
				swipperSlide2.style.background = "Black";
				swipperSlide2.appendChild(createTabs()); 		//Create tabs on page 2
									
				swipperWrapper.appendChild(swipperSlide2);
				
				//Page 3 - Search by name
				var swipperSlide3 = document.createElement("div");
				swipperSlide3.className = "fullSize";
				swipperSlide3.className = "swiper-slide";
				swipperSlide3.style.borderRadius = "10px";
				swipperSlide3.style.background =  "Black";															
				swipperSlide3.appendChild(createSearchTab());	//Create search results on page 3
				
				swipperWrapper.appendChild(swipperSlide3);

			swipperContainer.appendChild(swipperWrapper);
		body.appendChild(swipperContainer); 		
				
		//Little dots at the bottom of the page to show number of pages to swipe
		var pagination = document.createElement("div");
		pagination.className = "pagination";
		body.appendChild(pagination);

}//End createDraftPage

//Draw the team table on page 1
function createTeamTable()
{
	//Create Draft table team
	var teamTbl = document.createElement("table");
	teamTbl.setAttribute("id", "draftedTeamTable");
	teamTbl.setAttribute('border', '3');
		//Create table body
		var tblBody = document.createElement("tbody");
			//Create Header row
			var tblHeader = document.createElement("tr");
			tblHeader.setAttribute("id", "draftedTableRowHeader");
				//Create FantasyPosition column
				var header_pos = document.createElement("td");
				header_pos.style.width = "20%";
				header_pos.appendChild(document.createTextNode("Pos."));
				tblHeader.appendChild(header_pos);
				//Create name column
				var header_nme = document.createElement("td");
				header_nme.style.width = "60%";
				header_nme.appendChild(document.createTextNode("Name"));
				tblHeader.appendChild(header_nme);
				//Create CurrentAuctionValue column
				var header_val = document.createElement("td");
				header_val.style.width = "20%";
				header_val.appendChild(document.createTextNode("Value"));
				tblHeader.appendChild(header_val);
			//Add header row to table
			tblBody.appendChild(tblHeader);
			//Create QB row
			var tblQBrow = document.createElement("tr");
			tblQBrow.setAttribute("id", "qbRow");
			tblQBrow.style.textAlign = "center";
				//Create FantasyPosition column
				var qb_pos = document.createElement("td");
				qb_pos.appendChild(document.createTextNode("QB"));
				tblQBrow.appendChild(qb_pos);
				//Create QB name
				var qb_nme = document.createElement("td");
				qb_nme.setAttribute("id", "qbDrafted");
				qb_nme.className = "draftedTablePlayerName";
				qb_nme.appendChild(document.createTextNode(draft.qb_nme_selected));
				tblQBrow.appendChild(qb_nme);
				//Create QB CurrentAuctionValue
				var qb_val = document.createElement("td");
				qb_val.setAttribute("id", "qbValue");
				qb_val.appendChild(document.createTextNode("$" + draft.qb_val_selected));
				tblQBrow.appendChild(qb_val);
			//Add QB row to table
			tblBody.appendChild(tblQBrow);
			//Create RB row
			var tblRBrow = document.createElement("tr");
			tblRBrow.setAttribute("id", "rbRow");
			tblRBrow.style.textAlign = "center";
				//Create FantasyPosition column
				var rb_pos = document.createElement("td");
				rb_pos.appendChild(document.createTextNode("RB"));
				tblRBrow.appendChild(rb_pos);
				//Create RB name
				var rb_nme = document.createElement("td");	
				rb_nme.setAttribute("id", "rbDrafted");
				rb_nme.className = "draftedTablePlayerName";
				rb_nme.appendChild(document.createTextNode(draft.rb_nme_selected));
				tblRBrow.appendChild(rb_nme);
				//Create RB CurrentAuctionValue
				var rb_val = document.createElement("td");
				rb_val.setAttribute("id", "rbValue");
				rb_val.appendChild(document.createTextNode("$" + draft.rb_val_selected));
				tblRBrow.appendChild(rb_val);
			//Add RB row to table
			tblBody.appendChild(tblRBrow);
			//Create WR row
			var tblWRrow = document.createElement("tr");
			tblWRrow.setAttribute("id", "wrRow");
			tblWRrow.style.textAlign = "center";
				//Create FantasyPosition column
				var wr_pos = document.createElement("td");
				wr_pos.appendChild(document.createTextNode("WR"));
				tblWRrow.appendChild(wr_pos);
				//Create WR name
				var wr_nme = document.createElement("td");
				wr_nme.setAttribute("id", "wrDrafted");				
				wr_nme.className = "draftedTablePlayerName";
				wr_nme.appendChild(document.createTextNode(draft.wr_nme_selected));
				tblWRrow.appendChild(wr_nme);
				//Create WR CurrentAuctionValue
				var wr_val = document.createElement("td");
				wr_val.setAttribute("id", "wrValue");
				wr_val.appendChild(document.createTextNode("$" + draft.wr_val_selected));
				tblWRrow.appendChild(wr_val);
			//Add WR row to table
			tblBody.appendChild(tblWRrow);
			//Create Flex row
			var tblFLEXrow = document.createElement("tr");
			tblFLEXrow.setAttribute("id", "flexRow");
			tblFLEXrow.style.textAlign = "center";
				//Create FantasyPosition column
				var flex_pos = document.createElement("td");
				flex_pos.appendChild(document.createTextNode("FLEX"));
				tblFLEXrow.appendChild(flex_pos);
				//Create FLEX name
				var flex_nme = document.createElement("td");
				flex_nme.setAttribute("id", "flexDrafted");				
				flex_nme.className = "draftedTablePlayerName";
				flex_nme.appendChild(document.createTextNode(draft.flex_nme_selected));
				tblFLEXrow.appendChild(flex_nme);
				//Create FLEX CurrentAuctionValue
				var flex_val = document.createElement("td");
				flex_val.setAttribute("id", "flexValue");
				flex_val.appendChild(document.createTextNode("$" + draft.flex_val_selected));
				tblFLEXrow.appendChild(flex_val);
			//Add FLEX row to table
			tblBody.appendChild(tblFLEXrow);
			//Create K row
			var tblKrow = document.createElement("tr");
			tblKrow.setAttribute("id", "kRow");
			tblKrow.style.textAlign = "center";
				//Create FantasyPosition column
				var k_pos = document.createElement("td");
				k_pos.appendChild(document.createTextNode("K"));
				tblKrow.appendChild(k_pos);
				//Create K name
				var k_nme = document.createElement("td");	
				k_nme.className = "draftedTablePlayerName";
				k_nme.setAttribute("id", "kDrafted");
				k_nme.appendChild(document.createTextNode(draft.k_nme_selected));
				tblKrow.appendChild(k_nme);
				//Create K CurrentAuctionValue
				var k_val = document.createElement("td");
				k_val.setAttribute("id", "kValue");
				k_val.appendChild(document.createTextNode("$" + draft.k_val_selected));
				tblKrow.appendChild(k_val);
			//Add K row to table
			tblBody.appendChild(tblKrow);
	//Add data of table to the table
	teamTbl.appendChild(tblBody);
	//Return table to add table to team slide
	return teamTbl;
}//End createTeamTable 

//Draw and create the tabs on page 2
function createTabs()
{

	//Create div to hold tabs
	var tabs = document.createElement("div");
	tabs.setAttribute("id", "tabs");
	tabs.className = "tabsStyle";				
	
		//Create tabs
		var ul = document.createElement("ul");	
			var qb_li = document.createElement("li");
				var a1 = document.createElement("a");
					a1.setAttribute("href", "#tabs-1");	
					a1.innerHTML = "QB";
				qb_li.appendChild(a1);
			ul.appendChild(qb_li);
			var rb_li = document.createElement("li");
				var a2 = document.createElement("a");
					a2.setAttribute("href", "#tabs-2");
					a2.innerHTML = "RB";
				rb_li.appendChild(a2);
			ul.appendChild(rb_li);
			var wr_li = document.createElement("li");
				var a3 = document.createElement("a");
					a3.setAttribute("href", "#tabs-3");
					a3.innerHTML = "WR";
				wr_li.appendChild(a3);
			ul.appendChild(wr_li);
			var te_li = document.createElement("li");
				var a3 = document.createElement("a");
					a3.setAttribute("href", "#tabs-4");
					a3.innerHTML = "TE";
				te_li.appendChild(a3);
			ul.appendChild(te_li);				
			var k_li = document.createElement("li");
				var a4 = document.createElement("a");
					a4.setAttribute("href", "#tabs-5");
					a4.innerHTML = "K";
				k_li.appendChild(a4);
			ul.appendChild(k_li);
		tabs.appendChild(ul);
		
		//Fetch draftable players
		fetchPlayers(getLeagueTimeSlot());
		
		//Tab1 - QB
		var qb_tab = document.createElement("div");
		qb_tab.className = "tabs";
		qb_tab.setAttribute("id", "tabs-1");
		qb_tab.appendChild(createPlayerList(posEnum.qb));
		tabs.appendChild(qb_tab);
		
		//Tab2 - RB
		var rb_tab = document.createElement("div");
		rb_tab.className = "tabs";
		rb_tab.setAttribute("id", "tabs-2");
		rb_tab.appendChild(createPlayerList(posEnum.rb));
		tabs.appendChild(rb_tab);
		
		//Tab3 - WR
		var wr_tab = document.createElement("div");
		wr_tab.className = "tabs";
		wr_tab.setAttribute("id", "tabs-3");
		wr_tab.appendChild(createPlayerList(posEnum.wr));
		tabs.appendChild(wr_tab);
		
		//Tab4 - TE
		var te_tab = document.createElement("div");
		te_tab.className = "tabs";
		te_tab.setAttribute("id", "tabs-4");
		te_tab.appendChild(createPlayerList(posEnum.te));
		tabs.appendChild(te_tab);
		
		//Tab4 - K
		var k_tab = document.createElement("div");
		k_tab.className = "tabs";
		k_tab.setAttribute("id", "tabs-5");
		k_tab.appendChild(createPlayerList(posEnum.k));
		tabs.appendChild(k_tab);
	
	//Return to tabs to add to page
	return tabs;

}//End createTabs

//Create list of draftable players for the tabs
function createPlayerList(FantasyPosition)
{
	//Create draft table
	var draftTbl = document.createElement("table");
	draftTbl.className = "draftProspectTable";
		//Create table
		var draftTblBody = document.createElement("tbody");					
				
			//Retrieve players
			var list = getPositionPlayers(FantasyPosition);
			
			//Loop through players
			var i = 0;
			while( i < list.length )
			{
				//Rows of names and draft button
				var player_row = document.createElement("tr");							
				
					//Player Name
					var name = document.createElement("td");
					name.className = "draftProspectName";
					name.appendChild(document.createTextNode("(" + list[i].CurrentTeam + ") " + list[i].LastName + ", " + list[i].FirstName));
					player_row.appendChild(name);	
						
					//Draft button
					var draft = document.createElement("td");
					draft.className = "draftButtonColumn";
					draft.textAlign = "right";
						var draft_btn = document.createElement("a");
						draft_btn.className = "draftProspectButton";
						draft_btn.innerHTML = "$" + list[i].CurrentAuctionValue;
						draft_btn.CurrentAuctionValue = list[i];
						draft_btn.setAttribute("href", "javascript:draftPlayer('" + JSON.stringify(draft_btn.CurrentAuctionValue) +"')");										
						draft.appendChild(draft_btn);		
					player_row.appendChild(draft);
													
				draftTblBody.appendChild(player_row);
				i++;
			}

		draftTbl.appendChild(draftTblBody);
		
		return draftTbl;
}

//Create list of draftable players for the search bar
function createPlayerList2(FantasyPosition)
{
	//Create draft table
	var draftTbl = document.createElement("table");
	draftTbl.className = "draftProspectTable";
		//Create table
		var draftTblBody = document.createElement("tbody");		
				
			//Retrieve players
			var list = getPositionPlayers(FantasyPosition);
			
			//Loop through players
			var i = 0;
			while( i < list.length )
			{
				//Rows of names and draft button
				var player_row = document.createElement("tr");					
				
					//Player Name
					var name = document.createElement("td");
					name.className = "draftProspectName";
					name.style.paddingLeft = "11px";
					name.appendChild(document.createTextNode(list[i].FantasyPosition + ": (" + list[i].CurrentTeam + ") " + list[i].LastName + ", " + list[i].FirstName));
					player_row.appendChild(name);	
						
					//Draft button
					var draft = document.createElement("td");
					draft.className = "draftButtonColumn";
					draft.textAlign = "right";
						var draft_btn = document.createElement("a");
						draft_btn.className = "draftProspectButton";
						draft_btn.innerHTML = "$" + list[i].CurrentAuctionValue;
						draft_btn.CurrentAuctionValue = list[i];
						draft_btn.setAttribute("href", "javascript:draftPlayer('" + JSON.stringify(draft_btn.CurrentAuctionValue) +"')");										
						draft.appendChild(draft_btn);		
					player_row.appendChild(draft);
													
				draftTblBody.appendChild(player_row);
				i++;
			}

		draftTbl.appendChild(draftTblBody);
		
		return draftTbl;
}

//Fetchs valid players to be drafted
function getPositionPlayers(FantasyPosition)
{
	//If QBs requested
	if( FantasyPosition == posEnum.qb )
	{		
		return draft.qbPlayerList;
	}
	//If RBs requested
	else if( FantasyPosition == posEnum.rb )
	{
		return draft.rbPlayerList;
	}
	//If WRs requested
	else if( FantasyPosition == posEnum.wr )
	{
		return draft.wrPlayerList;
	}	
	//If TEs requested
	else if( FantasyPosition == posEnum.te )
	{
		return draft.tePlayerList;
	}
	//If Ks requested
	else if( FantasyPosition == posEnum.k )
	{
		return draft.kPlayerList;
	}
	//If searched players
	else if( FantasyPosition == posEnum.searched )
	{
		return draft.searchPlayerList;
	}
}

//Create search tab
function createSearchTab()
{
	//Create div for the search page
	var searchDiv = document.createElement("div");
	searchDiv.setAttribute("id", "searchDiv");
	searchDiv.style.width = "100%";
	searchDiv.style.height = "100%";
	
		//Create search header
		var searchHeader = document.createElement("h4");
		searchHeader.innerHTML = "Search for player:";
		searchHeader.style.textAlign = "center";
		searchHeader.style.margin = "0px";
		searchHeader.style.paddingTop = "7px";
		searchHeader.style.paddingBottom = "7px";
		searchDiv.appendChild(searchHeader);
		
		//Create the search bar
		var searchBar = document.createElement("input");
		searchBar.setAttribute("id", "searchBar");
		searchBar.className = "swiper-no-swiping";
		searchBar.type = "text";
		searchBar.setAttribute("maxLength", 30);
		searchBar.style.width = "65%";
		searchBar.style.marginLeft = "8px";
		searchDiv.appendChild(searchBar);
		
		//Create Search button
		var searchBtn = document.createElement("a");						
		searchBtn.className = "draftProspectButton";					
		searchBtn.setAttribute("href", "javascript:searchForPlayer(searchBar.value)");						
		searchBtn.style.textAlign = "center";
		searchBtn.style.marginRight = "8px";
		searchBtn.style.padding = ".5vh 1.5vw .5vh 1.5vw";
		searchBtn.innerHTML = "Search";
		searchBtn.style.width = "21%";
		searchDiv.appendChild(searchBtn);
				
		//Div to display search results
		var resultDiv = document.createElement("div");
		resultDiv.setAttribute("id", "resultDiv");
		resultDiv.style.overflowY = "auto";
		resultDiv.style.width = "100%";
		resultDiv.style.height = "100%";
		searchDiv.appendChild(resultDiv);
			
	return searchDiv;	
}



/* SEARCH FOR PLAYERS ON TAB3 functions */

function searchForPlayer(searchName)
{
	//Reset search player list
	draft.searchPlayerList = [];
	
	//Save length of string your searching for
	var searchLength = searchName.length;
	searchName = searchName.toUpperCase();

	//If value to search for
	if(searchName)
	{
		//Loop through list of playable players to find possible searched for players
		for( var i = 0; i < draft.playablePlayerList.length; i++)
		{
			//Find min last name length
			var lnmin = Math.min(searchLength, draft.playablePlayerList[i].LastName.length);
			var lname = (draft.playablePlayerList[i].LastName).toUpperCase(); 
			
			//Find min first name length
			var fnmin = Math.min(searchLength, draft.playablePlayerList[i].FirstName.length);
			var fname = (draft.playablePlayerList[i].FirstName).toUpperCase();
		
			//Check first name and last name
			if( lname.substring(0, lnmin) == searchName.substring(0, lnmin) || fname.substring(0, fnmin) == searchName.substring(0, fnmin))
			{
				//Add player to list
				draft.searchPlayerList.push(draft.playablePlayerList[i]);
			}
		}
	}

	//Clear result boxes and add new search list
	var resultDiv = document.getElementById("resultDiv");
	resultDiv.innerHTML = "";
	resultDiv.appendChild(createPlayerList2(posEnum.searched));	
	
	//Take focus off search bar
	defocusSearch();
}

//Take focus off search bar
function defocusSearch()
{
	var searchBar = document.getElementById("searchBar");
	searchBar.blur();
}



/* RETRIEVE AND SORT THE PLAYERS INTO FantasyPosition LISTS functions */

//Get players JSON info
function fetchPlayers(leagueSlot)
{
	//leagueSlot is the timeSlot enumeration to represent which games are in play
	//Find time slots for league 
	if(leagueSlot[0] == "1")			//Wants Thur game
	{
		draft.thurTimeCheck = timeSlot.thur;
	}
	if(leagueSlot[1] == "1")			//Wants Sun 1 game
	{
		draft.sun1TimeCheck = timeSlot.sun1;
	}
	if(leagueSlot[2] == "1")			//Wants Sun 2 game
	{
		draft.sun2TimeCheck = timeSlot.sun2;
	}
	if(leagueSlot[3] == "1")			//Wants Sun 3 game
	{
		draft.sun3TimeCheck = timeSlot.sun3;
	}
	if(leagueSlot[4] == "1")			//Wants Mon game
	{
		draft.monTimeCheck = timeSlot.mon;
	}

	//Find player ids from list of games/players
	findPlayablePlayerIds(getPlayerIds());
	
	//Find player info from the player ids
	findPlayablePlayerInfo(getPlayerList());

	//Sort complete list of players by value
	draft.playablePlayerList.sort(function (a,b) {
		if ( a.CurrentAuctionValue < b.CurrentAuctionValue )
			return 1;
		if ( a.CurrentAuctionValue > b.CurrentAuctionValue )
			return -1;
		return 0;			
	});	
		
	//Filter players into positions	
	filterPlayers(draft.playablePlayerList);
}

//Find player Ids that our in the time slot
function findPlayablePlayerIds(playerList)
{
	//Go through list of players
	for(var i = 0; i < playerList.length; i++)
	{
		var check = playerList[i].SlotID.trim();
		if(check == "0") {
			var checkSlot = "0000000";
		}
		else {
			var checkSlot = playerList[i].SlotID.substring(2,7);
		}

		
		//Check to see if the player is in the league time slot and save the player id
		//if(playerList[i].SlotID == draft.thurTimeCheck || playerList[i].SlotID == draft.sun1TimeCheck || playerList[i].SlotID == draft.sun2TimeCheck || playerList[i].SlotID == draft.sun3TimeCheck || playerList[i].SlotID == draft.monTimeCheck)		
		if(checkSlot == draft.thurTimeCheck || checkSlot == draft.sun1TimeCheck || checkSlot == draft.sun2TimeCheck || checkSlot == draft.sun3TimeCheck || checkSlot == draft.monTimeCheck)
		{
			//Check to make sure the player is a valid position
			if(playerList[i].FantasyPosition == posEnum.QB || playerList[i].FantasyPosition == posEnum.RB || playerList[i].FantasyPosition == posEnum.WR || playerList[i].FantasyPosition == posEnum.TE || playerList[i].FantasyPosition == posEnum.K)
			{	
				//Player is in the league time slot so save the player id
				draft.playerIDList.push(playerList[i].NFLPlayerID);
			}
		}
	}
	
	//Sort the ID's in ascending order
	draft.playerIDList.sort(function (a,b) {
		return a - b;
	});	
}

//Find the players info based on the ids from the time slots
function findPlayablePlayerInfo(playerInfoList)
{
	//Sort the playerInfo list by Id to run through both id lists linearly
	playerInfoList.sort(function (a,b) {
		return a.NFLPlayerID - b.NFLPlayerID;	
	});

	//Find player info from the ids
	var playerInfoListSpot = 0;
	for( var i = 0; i < draft.playerIDList.length; i++)
	{
		for( var j = playerInfoListSpot; j < playerInfoList.length; j++)
		{
			//If player ids are a match
			if( draft.playerIDList[i] == playerInfoList[j].NFLPlayerID)
			{
				//Save player info and break inner forloop
				draft.playablePlayerList.push(playerInfoList[j]);
				playerInfoListSpot = j + 1;
				break;
			}
		}
	}
	
	//Clear id list
	draft.playerIDList = [];
}

//Get the player Ids with their game/time slot id
function getPlayerIds()
{
	//Call API for list of player ids and game slot ids
	var URL = "http://cryptic-waters-6734.herokuapp.com/weekplayerdata.json";
	var json = getRequest(URL);
	return json;
	//return test.timeSlotList
}

//Get the list of players
function getPlayerList()
{	
	//Call the api for the list of player info with player ids
	var URL = "http://cryptic-waters-6734.herokuapp.com/seasonplayerdata.json";
	var json = getRequest(URL);
	return json;
	//return test.playerList;
}

//Get league time slot
function getLeagueTimeSlot()
{
	return leagueInfo[2];
	//return test.gameSlotb;
}

//Filters the players into FantasyPosition arrays
function filterPlayers(playerList)
{
	for( var i = 0; i < playerList.length; i++)
	{
		playerList[i].CurrentAuctionValue = playerList[i].CurrentAuctionValue * 3;

		if(playerList[i].FantasyPosition == posEnum.qb)
		{
			draft.qbPlayerList.push(playerList[i]);
		}
		else if(playerList[i].FantasyPosition == posEnum.rb)
		{
			draft.rbPlayerList.push(playerList[i]);
		}
		else if(playerList[i].FantasyPosition == posEnum.wr)
		{
			draft.wrPlayerList.push(playerList[i]);
		}
		else if(playerList[i].FantasyPosition == posEnum.te)
		{
			draft.tePlayerList.push(playerList[i]);
		}
		else if(playerList[i].FantasyPosition == posEnum.k)
		{
			draft.kPlayerList.push(playerList[i]);
		}
	}
}



/* USER DRAFTS A PLAYER functions */

//Handles the draft clicks
function draftPlayer(player_clicked)
{ 
//Gets object from user button click
var player = JSON.parse(player_clicked);

//Check if QB selected
if( player.FantasyPosition == posEnum.qb)
{
//Check if QB hasn't already been drafted
if( draft.qb_id_selected == posEnum.empty )
{
//Make sure user has money left to purchase player
if( (draft.teamBudget - player.CurrentAuctionValue) >= 0 )
{
//Ask user to confirm pick
var confirmation = confirm("Are you sure you want to draft " + player.FirstName + " " + player.LastName + " for $" + player.CurrentAuctionValue + "?");
if(confirmation)
{

//Set new player name
draft.qb_nme_selected = player.FirstName + " " + player.LastName;

//Set QB drafted name
var qb = document.getElementById("qbDrafted");
qb.innerHTML = draft.qb_nme_selected;

//Decrement budget
updateBudget(player.CurrentAuctionValue);

//Set QB drafted CurrentAuctionValue
draft.qb_val_selected = player.CurrentAuctionValue;
var val = document.getElementById("qbValue");
val.innerHTML = "$" + draft.qb_val_selected;

//Set Qb drafted id
draft.qb_id_selected = player.NFLPlayerID;

//Change table style
updateDraftStyle("qbRow");
}

}
else
{
alert("You cant afford " + player.FirstName + " " + player.LastName + ".");
}
}
else
{
alert("You've already drafted a QB.");
}
}
//Check if RB selected
else if( player.FantasyPosition == posEnum.rb)
{
//Check if RB hasn't already been drafted
if( draft.rb_id_selected == posEnum.empty )
{
//Make sure user has money left to purchase player
if( (draft.teamBudget - player.CurrentAuctionValue) >= 0 )
{
//Ask user to confirm pick
var confirmation = confirm("Are you sure you want to draft " + player.FirstName + " " + player.LastName + " for $" + player.CurrentAuctionValue + "?");
if(confirmation)
{
//Set new player name
draft.rb_nme_selected = player.FirstName + " " + player.LastName;

//Set RB drafted name
var rb = document.getElementById("rbDrafted");
rb.innerHTML = draft.rb_nme_selected;

//Decrement budget
updateBudget(player.CurrentAuctionValue);

//Set RB drafted CurrentAuctionValue
draft.rb_val_selected = player.CurrentAuctionValue;
var val = document.getElementById("rbValue");
val.innerHTML = "$" + draft.rb_val_selected;

//Set RB drafted id
draft.rb_id_selected = player.NFLPlayerID;

//Change table style
updateDraftStyle("rbRow");
}
}
else
{
alert("You cant afford " + player.FirstName + " " + player.LastName + ".");
}
}
//If they have already have a RB then check FLEX position
else if( draft.flex_id_selected == posEnum.empty )
{
udpdateFlexPosition(player)
}
else
{
alert("You don't have room for another RB on your roster.");
}
}

//Check if WR selected
else if( player.FantasyPosition == posEnum.wr)
{
//Check if WR hasn't already been drafted
if( draft.wr_id_selected == posEnum.empty )
{
//Make sure user has money left to purchase player
if( (draft.teamBudget - player.CurrentAuctionValue) >= 0 )
{
//Ask user to confirm pick
var confirmation = confirm("Are you sure you want to draft " + player.FirstName + " " + player.LastName + " for $" + player.CurrentAuctionValue + "?");
if(confirmation)
{
//Set new player name
draft.wr_nme_selected = player.FirstName + " " + player.LastName;

//Set WR drafted name
var wr = document.getElementById("wrDrafted");
wr.innerHTML = draft.wr_nme_selected;

//Decrement budget
updateBudget(player.CurrentAuctionValue);

//Set WR drafted CurrentAuctionValue
draft.wr_val_selected = player.CurrentAuctionValue;
var val = document.getElementById("wrValue");
val.innerHTML = "$" + draft.wr_val_selected;


//Set WR drafted id
draft.wr_id_selected = player.NFLPlayerID;

//Change table style
updateDraftStyle("wrRow");
}

}
else
{
alert("You cant afford " + player.FirstName + " " + player.LastName + ".");
}
}
//If they already have a WR then check FLEX position
else if( draft.flex_id_selected == posEnum.empty )
{
udpdateFlexPosition(player);
}
else
{
alert("You don't have room for another WR on your roster.");
}

}
//Check if TE selected
else if( player.FantasyPosition == posEnum.te)
{
//Since no TE slot check Flex position
if( draft.flex_id_selected == posEnum.empty )
{
udpdateFlexPosition(player);
}
else
{
alert("You don't have room for another TE on your roster.");
}

}
//Check if K selected
else if( player.FantasyPosition == posEnum.k)
{
//Check if K hasn't already been drafted
if( draft.k_id_selected == posEnum.empty )
{
//Make sure user has money left to purchase player
if( (draft.teamBudget - player.CurrentAuctionValue) >= 0 )
{
//Ask user to confirm pick
var confirmation = confirm("Are you sure you want to draft " + player.FirstName + " " + player.LastName + " for $" + player.CurrentAuctionValue + "?");
if(confirmation)
{
//Set new player name
draft.k_nme_selected = player.FirstName + " " + player.LastName;;

//Set K drafted name
var k = document.getElementById("kDrafted");
k.innerHTML = draft.k_nme_selected;

//Decrement budget
updateBudget(player.CurrentAuctionValue);

//Set K drafted CurrentAuctionValue
draft.k_val_selected = player.CurrentAuctionValue;
var val = document.getElementById("kValue");
val.innerHTML = "$" + draft.k_val_selected;

//Set K drafted id
draft.k_id_selected = player.NFLPlayerID;

//Change table style
updateDraftStyle("kRow");
}

}
else
{
alert("You cant afford " + player.FirstName + " " + player.LastName + ".");
}
}
else
{
alert("You've already drafted a K.");
}
}
//Position not recognized
else
{
alert("Error: " + player.FirstName + " " + player.LastName + "'s position was not reconginzed. Please draft another player.");
}


//Check if Team is full
checkTeam();
}

//Decrement budget
function updateBudget(value)
{
	//Decrement budget
	draft.teamBudget = draft.teamBudget - value;
	var budget = document.getElementById("budget");
	budget.innerHTML = "Remaining Budget: $" + draft.teamBudget;
}

//Update drafted table's style
function updateDraftStyle(row)
{
	var rowNew = document.getElementById(row);
	rowNew.style.color = "black";
	rowNew.style.fontWeight = "bold";
}

//Update Flex position
function udpdateFlexPosition(player)
{
//Check to see if they've already drafted this player
if( draft.rb_id_selected != player.NFLPlayerID && draft.wr_id_selected != player.NFLPlayerID )
{
//Make sure user has money left to purchase player
if( (draft.teamBudget - player.CurrentAuctionValue) >= 0 )
{
//Ask user to confirm pick
var confirmation = confirm("Are you sure you want to draft " + player.FirstName + " " + player.LastName + " for $" + player.CurrentAuctionValue + "?");
if(confirmation)
{
//Set new player name
draft.flex_nme_selected = player.FirstName + " " + player.LastName;

//Set Flex drafted name
var flex = document.getElementById("flexDrafted");
flex.innerHTML = draft.flex_nme_selected;

//Decrement budget
updateBudget(player.CurrentAuctionValue);

//Set Flex drafted CurrentAuctionValue
draft.flex_val_selected = player.CurrentAuctionValue;
var val = document.getElementById("flexValue");
val.innerHTML = "$" + draft.flex_val_selected;

//Set Flex drafted id
draft.flex_id_selected = player.NFLPlayerID;

//Change table style
updateDraftStyle("flexRow");
}
}
else
{
alert("You cant afford " + player.FirstName + " " + player.LastName + ".");
}
}
else
{
alert("You've already drafted " + player.FirstName + " " + player.LastName + ".");
}
}

//Check is team is completely drafted
function checkTeam()
{
	if( draft.qb_id_selected != -1 &&  draft.rb_id_selected != -1 &&  draft.wr_id_selected != -1 &&  draft.flex_id_selected != -1 && draft.k_id_selected != -1)
	{
		// make json of players for roster
		var rosterData = {
			roster : {
				rosterID : "0",
				username : userInfo[0],
				leagueID : leagueInfo[1],
				qb : draft.qb_id_selected,
				flex : draft.flex_id_selected,
				k : draft.k_id_selected,
				wr : draft.wr_id_selected,
				rb : draft.rb_id_selected
			}
		}


		// POST to server to create roster
		var rosterURL = "http://cryptic-waters-6734.herokuapp.com/rosters.json";
		var rosterJson = postRequest(rosterURL, rosterData);

		if(rosterJson == 0) {
			alert("Failed to create roster; please try again");
			location.reload();
		}
		else {

			// make json for to update user's roster id
			var userData = {
				user : {
					rosterID : rosterJson.id
				}
			}

			// PUT to user to add the new roster id
			var userURL = 'http://cryptic-waters-6734.herokuapp.com/users/'+userInfo[1]+'.json';
			var userJson = putRequest(userURL, userData);

			if(userJson == 0) {
				alert("Failed to update user info; please try again");
				var deleteJson = deleteRequest('http://cryptic-waters-6734.herokuapp.com/rosters/'+rosterJson.id+'.json');
				location.reload();
			}
			else {
				alert("Congratulations! Your team is complete.");
				location.reload();
			}
		}
	}
}
 
 
 
/* JAVASCRIPT/JQUERY functions */ 
 
//Enable swipping between pages
var mySwiper = new Swiper('.swiper-container',{
	pagination: '.pagination',
	loop: false,
	paginationClickable: true,
	releaseFormElements: true,
	simulateTouch: true,
	noSwiping: true
})

//Enable tabs for page 2
$("#tabs").tabs();

//Enable Scrolling on tab pages
function isTouchDevice(){
try{
document.createEvent("TouchEvent");
return true;
}catch(e){
return false;
}
}


function touchScroll(id){
if(isTouchDevice()){ //if touch events exist...
var el=document.getElementById(id);
var scrollStartPos=0;


document.getElementById(id).addEventListener("touchstart", function(event) {
scrollStartPos=this.scrollTop+event.touches[0].pageY;

},false);


document.getElementById(id).addEventListener("touchmove", function(event) {
this.scrollTop=scrollStartPos-event.touches[0].pageY;
},false);
}
}


touchScroll('tabs-1');
touchScroll('tabs-2');
touchScroll('tabs-3');
touchScroll('tabs-4');
touchScroll('tabs-5');
touchScroll('resultDiv');