function loadScript(src){              
    var e = document.createElement("script");
    e.src = src;
    e.type="text/javascript";
    document.getElementsByTagName("body")[0].appendChild(e);
}
function loadCSS(src){
    var fileref=document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", src);
    document.getElementsByTagName("head")[0].appendChild(fileref); 
}