var body = document.getElementById("contentWrapper");

// create all the html variables
var createHeader = document.createElement("h2");
var leagueHeader = document.createElement("h2");
var numHeader = document.createElement("h2");
var slotsHeader = document.createElement("h2");
var passwordHeader = document.createElement("h2");

var leagueName = document.createElement("input");
var teamNum = document.createElement("select");
var timeSlots = document.createElement("input");
var password = document.createElement("input");

var createBtn = document.createElement("button");

// set all the attributes of the html variables
createHeader.innerHTML = "Create League";
createHeader.className = "underline";

leagueHeader.innerHTML = "League Name:";
numHeader.innerHTML = "Number of Teams:";
slotsHeader.innerHTML = "Game Times Slot(s):";
passwordHeader.innerHTML = "(Optional) Private Password";

leagueName.id = "leagueName";
leagueName.type = "text";

teamNum.id = "teamNum";       
teamNum.options[teamNum.options.length] = new Option("2","2");  
teamNum.options[teamNum.options.length] = new Option("3","3");  
teamNum.options[teamNum.options.length] = new Option("4","4");  
teamNum.options[teamNum.options.length] = new Option("5","5");
teamNum.options[teamNum.options.length] = new Option("6","6");

timeSlots.id = "timeSlots";
timeSlots.type = "text";

password.id = "password";
password.type = "text";

createBtn.innerHTML = "Create";
createBtn.className = "myButton";
createBtn.onclick = function () {
        localStorage["page"] = "js/league/createTeam.js";
        location.reload();
}

body.appendChild(createHeader);
body.appendChild(leagueHeader);
body.appendChild(leagueName);
body.appendChild(document.createElement("br"));
body.appendChild(numHeader);
body.appendChild(teamNum);
body.appendChild(document.createElement("br"));
body.appendChild(slotsHeader);
body.appendChild(timeSlots);
body.appendChild(document.createElement("br"));
body.appendChild(passwordHeader);
body.appendChild(password);
body.appendChild(document.createElement("br"));
body.appendChild(createBtn);