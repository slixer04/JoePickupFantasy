var body = document.getElementById("contentWrapper");

// fill in the logged in form
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

create.innerHTML = "Create League";
join.innerHTML = "Join League";
view.innerHTML = "View League";

create.onclick = function() {
    window.location = "htmlPages/create/index.html";
};
join.onclick = function() {
    window.location = "htmlPages/join/index.html";
};
view.onclick = function() {
    window.location = "htmlPages/view/index.html";
};
                 

body.appendChild(create);
body.appendChild(join);
body.appendChild(view);