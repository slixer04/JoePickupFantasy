/* variables need for construction of header */
var header = document.getElementById("headerWrapper");
var loggedIn = localStorage.getItem("loggedIn");

/* constructing elements of the header */
var logo = document.createElement("img");
logo.src="img/introPlayer.png";
logo.className = "footballPlayer";

var logout = document.createElement("span");
logout.className = "logout";
if(loggedIn == null) {
	logout.innerHTML = "Sign up";
	logout.onclick = function () {
		alert("sign up goes here!");
	}
}
else {
	logout.innerHTML = "Log out";
	logout.onclick = function () {
		localStorage.removeItem("loggedIn");
		localStorage.removeItem("page");
     	location.reload();
	}
}

header.appendChild(logout);
header.appendChild(logo);
