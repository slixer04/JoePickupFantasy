var body = document.getElementById("contentWrapper");

// fill in the logged in form
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

create.innerHTML = "Create League";
create.className = "myButton";

join.innerHTML = "Join League";
join.className = "myButton";

view.innerHTML = "View League";
view.className = "myButton";

create.onclick = function() {
    localStorage["page"] = "js/league/createLeague.js";
    location.reload();
};
join.onclick = function() {
    localStorage["page"] = "js/league/joinLeague.js";
    location.reload();
};
view.onclick = function() {
    //window.location = "htmlPages/view/index.html";
};

// add stylings for page                
body.style.textAlign = "center";
body.style.paddingTop = "90%";

// add elements to page
body.appendChild(create);
body.appendChild(join);
body.appendChild(view);