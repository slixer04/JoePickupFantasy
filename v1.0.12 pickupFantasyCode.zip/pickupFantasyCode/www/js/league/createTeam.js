var body = document.getElementById("contentWrapper");

// create elements
var createHeader = document.createElement("h2");
var nameHeader = document.createElement("h2");
var colorHeader = document.createElement("h2");

var form = document.createElement("form");

var redL = document.createElement("label");
var yellowL = document.createElement("label");
var blueL = document.createElement("label");
var greenL = document.createElement("label");

var teamName = document.createElement("input");
var red = document.createElement("input");
var yellow = document.createElement("input");
var blue = document.createElement("input");
var green = document.createElement("input");

var btn = document.createElement("button");

// set elements attributes
createHeader.innerHTML = "Create Team";
createHeader.className = "underline";
nameHeader.innerHTML = "Team Name:";
colorHeader.innerHTML = "Team Color:";

redT = document.createTextNode("Red");
yellowT = document.createTextNode("Yellow");
blueT = document.createTextNode("Blue");
greenT = document.createTextNode("Green");

teamName.type = "text";
red.type = "radio";
yellow.type = "radio";
blue.type = "radio";
green.type = "radio";

teamName.id = "teamName";

red.name = "color";
red.value = "red";

yellow.name = "color";
yellow.value = "yellow";

blue.name= "color";
blue.value = "blue";

green.name = "color";
green.value = "green";

btn.innerHTML = "Create";
btn.className = "myButton";
btn. onclick = function () {
	localStorage["page"] = "js/league/draftTeam.js";
    location.reload();

}

// create radio buttons
redL.appendChild(red);
redL.appendChild(redT);

blueL.appendChild(blue);
blueL.appendChild(blueT);

yellowL.appendChild(yellow);
yellowL.appendChild(yellowT);

greenL.appendChild(green);
greenL.appendChild(greenT);

// create form for radio buttons
form.appendChild(redL);
form.appendChild(document.createElement("br"));
form.appendChild(blueL);
form.appendChild(document.createElement("br"));
form.appendChild(yellowL);
form.appendChild(document.createElement("br"));
form.appendChild(greenL);

// put elements on the page
body.appendChild(createHeader);
body.appendChild(nameHeader);
body.appendChild(teamName);
body.appendChild(colorHeader);
body.appendChild(form);
body.appendChild(btn);